import Foundation

enum Side: String, Codable {
    case left, right

    var opposite: Side { self == .left ? .right : .left }
}

enum TeamId: String, Codable {
    case A, B

    var other: TeamId { self == .A ? .B : .A }
}

/// The court as you marked it during setup. Every scoring decision is measured
/// against these positions, which is why the ground line matters so much: it is
/// the line that separates a caught bottle from one on the grass.
struct Court: Codable, Equatable {
    var leftTop: Pt
    var rightTop: Pt
    var leftBase: Pt
    var rightBase: Pt
    var leftBottle: Box
    var rightBottle: Box
    var groundA: Pt
    var groundB: Pt
    var teamASide: Side = .left

    static let placeholder = Court(
        leftTop: Pt(x: 0.25, y: 0.45),
        rightTop: Pt(x: 0.75, y: 0.45),
        leftBase: Pt(x: 0.25, y: 0.80),
        rightBase: Pt(x: 0.75, y: 0.80),
        leftBottle: Box(x: 0.235, y: 0.415, w: 0.03, h: 0.035),
        rightBottle: Box(x: 0.735, y: 0.415, w: 0.03, h: 0.035),
        groundA: Pt(x: 0.05, y: 0.80),
        groundB: Pt(x: 0.95, y: 0.80)
    )

    func poleTop(_ side: Side) -> Pt { side == .left ? leftTop : rightTop }
    func poleBase(_ side: Side) -> Pt { side == .left ? leftBase : rightBase }
    func bottleBox(_ side: Side) -> Box { side == .left ? leftBottle : rightBottle }

    /// Generous box around a bottle's resting position on its pole.
    func restZone(_ side: Side) -> Box {
        bottleBox(side).expanded(by: 1.9, pad: 0.012)
    }

    func isOnPole(_ side: Side, _ box: Box) -> Bool {
        restZone(side).contains(box.center)
    }

    /// Positive above the ground line, negative below it.
    func heightAboveGround(_ p: Pt) -> Double {
        lineY(a: groundA, b: groundB, x: p.x) - p.y
    }

    func isAtGround(_ p: Pt, tolerance: Double = 0.035) -> Bool {
        heightAboveGround(p) <= tolerance
    }

    func team(for side: Side) -> TeamId {
        teamASide == side ? .A : .B
    }
}
