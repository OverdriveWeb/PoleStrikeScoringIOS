import SwiftUI

/// Tap six points and the court is defined. The ground line is the one that
/// matters most: it is what separates a caught bottle from one on the grass,
/// which is the difference between 2 points and 3.
struct CalibrationView: View {
    @EnvironmentObject var store: GameStore
    @EnvironmentObject var camera: CameraController
    @Environment(\.dismiss) private var dismiss

    private enum Step: Int, CaseIterable {
        case leftPole, rightPole, leftBottle, rightBottle, leftGround, rightGround

        var title: String {
            switch self {
            case .leftPole: return "Tap the top of the left pole"
            case .rightPole: return "Tap the top of the right pole"
            case .leftBottle: return "Tap the left bottle"
            case .rightBottle: return "Tap the right bottle"
            case .leftGround: return "Tap the ground at the left pole"
            case .rightGround: return "Tap the ground at the right pole"
            }
        }

        var hint: String {
            switch self {
            case .leftPole, .rightPole: return "The point the bottle rests on."
            case .leftBottle, .rightBottle: return "Its resting spot becomes the on-pole zone."
            case .leftGround, .rightGround: return "Where the pole meets the grass."
            }
        }
    }

    @State private var stepIndex = 0
    @State private var points: [Int: Pt] = [:]
    @State private var viewPoints: [Int: CGPoint] = [:]

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottom) {
                if camera.authorized {
                    CameraPreview(controller: camera)
                        .ignoresSafeArea()
                        .onTapGesture { location in
                            record(location)
                        }
                } else {
                    Theme.field.ignoresSafeArea()
                    Text("Camera access is needed to see the court.")
                        .foregroundStyle(Theme.muted)
                }

                ForEach(Array(viewPoints.keys.sorted()), id: \.self) { key in
                    if let p = viewPoints[key] {
                        Circle()
                            .stroke(Theme.disc, lineWidth: 2)
                            .frame(width: 22, height: 22)
                            .position(p)
                            .allowsHitTesting(false)
                    }
                }

                panel
            }
        }
        .background(Theme.field)
        .navigationTitle("Calibrate")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { camera.start() }
    }

    private var panel: some View {
        VStack(alignment: .leading, spacing: 10) {
            if stepIndex < Step.allCases.count {
                let step = Step.allCases[stepIndex]
                SectionLabel(text: "Step \(stepIndex + 1) of \(Step.allCases.count)")
                Text(step.title).font(.headline)
                Text(step.hint).font(.subheadline).foregroundStyle(Theme.muted)
                if stepIndex > 0 {
                    BigButton(title: "Back a step") { stepIndex -= 1 }
                }
            } else {
                SectionLabel(text: "Court marked")
                Text("Both poles, both bottles and the ground line are set.").font(.headline)
                Text("Lit objects seen right now: \(camera.blobCount)")
                    .font(.subheadline).foregroundStyle(Theme.muted)
                BigButton(title: "Save and start", tone: .primary) { saveCourt() }
                BigButton(title: "Start over") {
                    points = [:]
                    viewPoints = [:]
                    stepIndex = 0
                }
            }
        }
        .padding(18)
        .background(Theme.panel.opacity(0.94))
    }

    private func record(_ location: CGPoint) {
        guard stepIndex < Step.allCases.count,
              let normalized = camera.normalizedPoint(fromLayerPoint: location) else { return }
        points[stepIndex] = normalized
        viewPoints[stepIndex] = location
        stepIndex += 1
    }

    private func saveCourt() {
        guard let lp = points[0], let rp = points[1],
              let lb = points[2], let rb = points[3],
              let lg = points[4], let rg = points[5] else { return }

        let court = Court(
            leftTop: lp,
            rightTop: rp,
            leftBase: lg,
            rightBase: rg,
            leftBottle: Box(x: lb.x - 0.015, y: lb.y - 0.0175, w: 0.03, h: 0.035),
            rightBottle: Box(x: rb.x - 0.015, y: rb.y - 0.0175, w: 0.03, h: 0.035),
            groundA: lg,
            groundB: rg,
            teamASide: .left
        )
        store.saveCourt(court)
        camera.court = court
        camera.courtCalibrated = true
        camera.resetTracking()
        dismiss()
    }
}
