import AVFoundation
import SwiftUI
import UIKit

/// Owns the capture session and the whole per-frame path:
/// frame -> glow blobs -> classified detections -> tracker -> state machine.
///
/// Detection runs on the capture queue, never on the main thread — a 720p frame
/// scan plus flood fill is cheap, but doing it on the UI thread would still cost
/// you preview smoothness. Only the small published summary hops to main.
final class CameraController: NSObject, ObservableObject {
    @Published var authorized = false
    @Published var running = false
    @Published var status: StatusBadge = .watching
    @Published var notice: String?
    @Published var tracks: [Track] = []
    @Published var blobCount = 0
    @Published var analysisFPS = 0.0

    let session = AVCaptureSession()

    /// Touched only from `queue` once capture starts.
    let classifier = GlowClassifier()
    let machine = PlayStateMachine()
    private let tracker = Tracker()

    /// Set by the preview so taps can be converted into camera coordinates.
    weak var previewLayer: AVCaptureVideoPreviewLayer?

    var onOutcome: ((PlayOutcome) -> Void)?

    private let queue = DispatchQueue(label: "polescore.camera", qos: .userInitiated)
    private var configured = false
    private var lastAnalysis: Double = 0
    private var fpsWindow: [Double] = []

    // Written on main, read on the capture queue. Guarded by a lock because a
    // torn read of the court mid-frame would put the ground line in the wrong
    // place for exactly one decision — which is the decision that matters.
    private let lock = NSLock()
    private var _court: Court = .placeholder
    private var _threshold: Double = 0.62
    private var _scoringEnabled = true
    private var _frameInterval: Double = 1.0 / 24.0
    private var _rotation: Double = 0
    private var _courtCalibrated: Bool = false

    var court: Court {
        get { lock.lock(); defer { lock.unlock() }; return _court }
        set { lock.lock(); _court = newValue; lock.unlock() }
    }

    var threshold: Double {
        get { lock.lock(); defer { lock.unlock() }; return _threshold }
        set { lock.lock(); _threshold = newValue; lock.unlock() }
    }

    var scoringEnabled: Bool {
        get { lock.lock(); defer { lock.unlock() }; return _scoringEnabled }
        set { lock.lock(); _scoringEnabled = newValue; lock.unlock() }
    }

    /// True once the person has actually walked through Calibrate and saved
    /// real pole/bottle/ground points. Until then `court` is just
    /// `.placeholder` — plausible-looking numbers, not a real court — so the
    /// state machine is not run against it at all. Without this gate, any lit
    /// object that happens to land outside the placeholder's tiny rest zone
    /// reads as "bottle already off the pole" and starts a play on the spot,
    /// with nothing having moved.
    var courtCalibrated: Bool {
        get { lock.lock(); defer { lock.unlock() }; return _courtCalibrated }
        set { lock.lock(); _courtCalibrated = newValue; lock.unlock() }
    }

    /// Rotation applied to BOTH the preview and the analysis buffer, so what
    /// you see and what the detector measures never disagree. Landscape with
    /// the charging port on the right is 180 on most devices; the setting
    /// exists because the sensor's idea of "up" varies by model.
    var rotation: Double {
        get { lock.lock(); defer { lock.unlock() }; return _rotation }
        set {
            lock.lock(); _rotation = newValue; lock.unlock()
            applyRotation()
        }
    }

    func applyRotation() {
        let angle = rotation
        queue.async { [weak self] in
            guard let self else { return }
            for output in self.session.outputs {
                for connection in output.connections where connection.isVideoRotationAngleSupported(angle) {
                    connection.videoRotationAngle = angle
                }
            }
            DispatchQueue.main.async {
                if let preview = self.previewLayer?.connection,
                   preview.isVideoRotationAngleSupported(angle) {
                    preview.videoRotationAngle = angle
                }
            }
        }
    }

    func setAnalysisFPS(_ fps: Double) {
        lock.lock(); _frameInterval = 1.0 / max(4, fps); lock.unlock()
    }

    // MARK: - Session

    /// iOS terminates the process — no catchable error — if you touch the
    /// camera APIs without a usage description in place. So check first and
    /// report it rather than dying on launch.
    static var hasCameraUsageDescription: Bool {
        Bundle.main.object(forInfoDictionaryKey: "NSCameraUsageDescription") != nil
    }

    @MainActor
    func requestAccess() async {
        guard Self.hasCameraUsageDescription else {
            authorized = false
            notice = "Camera capability is missing. In Swift Playgrounds open App Settings, "
                + "add the Camera capability with a description, then run again."
            return
        }

        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            authorized = true
        case .notDetermined:
            authorized = await AVCaptureDevice.requestAccess(for: .video)
        default:
            authorized = false
        }
        if authorized { configure() }
    }

    func configure() {
        guard !configured, Self.hasCameraUsageDescription else { return }
        configured = true

        session.beginConfiguration()
        session.sessionPreset = .hd1280x720

        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else {
            session.commitConfiguration()
            publish { self.notice = "No rear camera available." }
            return
        }
        session.addInput(input)

        let output = AVCaptureVideoDataOutput()
        output.videoSettings = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarFullRange
        ]
        output.alwaysDiscardsLateVideoFrames = true
        output.setSampleBufferDelegate(self, queue: queue)
        if session.canAddOutput(output) { session.addOutput(output) }

        session.commitConfiguration()
        applyRotation()

        // Continuous auto exposure helps in the dark. Longer exposures smear a
        // flying disc into a streak, which the threshold still finds — one more
        // reason brightness beats a model on a lit set.
        if (try? device.lockForConfiguration()) != nil {
            if device.isExposureModeSupported(.continuousAutoExposure) {
                device.exposureMode = .continuousAutoExposure
            }
            if device.isFocusModeSupported(.continuousAutoFocus) {
                device.focusMode = .continuousAutoFocus
            }
            device.unlockForConfiguration()
        }
    }

    func start() {
        guard authorized, Self.hasCameraUsageDescription else { return }
        configure()
        queue.async { [session] in
            if !session.isRunning { session.startRunning() }
        }
        applyRotation()
        publish { self.running = true }
    }

    func stop() {
        queue.async { [session] in
            if session.isRunning { session.stopRunning() }
        }
        publish { self.running = false }
    }

    func resetTracking() {
        queue.async {
            self.tracker.reset()
            self.machine.reset()
            self.classifier.reset()
        }
    }

    /// Convert a tap in the preview into the normalized camera coordinates that
    /// the detector and the calibration both speak.
    func normalizedPoint(fromLayerPoint point: CGPoint) -> Pt? {
        guard let layer = previewLayer else { return nil }
        let device = layer.captureDevicePointConverted(fromLayerPoint: point)
        return Pt(x: Double(device.x), y: Double(device.y))
    }

    private func publish(_ block: @escaping () -> Void) {
        if Thread.isMainThread {
            block()
        } else {
            DispatchQueue.main.async(execute: block)
        }
    }
}

extension CameraController: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let timestamp = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sampleBuffer))

        lock.lock()
        let interval = _frameInterval
        let court = _court
        let cut = _threshold
        let scoring = _scoringEnabled
        let calibrated = _courtCalibrated
        lock.unlock()

        guard timestamp - lastAnalysis >= interval else { return }
        let previous = lastAnalysis
        lastAnalysis = timestamp

        var detector = GlowDetector()
        detector.threshold = cut

        let blobs = detector.detect(pixelBuffer)
        let detections = classifier.classify(blobs: blobs, court: court)
        let currentTracks = tracker.update(detections, timestamp: timestamp)

        // On a glow set a dark frame is the *good* case, so quality is about
        // whether anything is lit at all, not about exposure.
        let quality = blobs.isEmpty ? 0.35 : 0.95

        // Tracking still runs above (so the calibration screen and the debug
        // overlay always show what's actually lit) but the state machine only
        // sees frames once there's a real court to measure against. Otherwise
        // it just watches, no matter what's in frame.
        let result: MachineOutput
        if calibrated {
            result = machine.update(tracks: currentTracks, court: court, timestamp: timestamp, quality: quality)
        } else {
            machine.reset()
            result = MachineOutput(state: .idle, status: .paused, outcome: nil,
                                    notice: "Court isn't set up yet — calibrate it before scoring.")
        }

        var fps = 0.0
        if previous > 0 {
            let delta = timestamp - previous
            if delta > 0 {
                fpsWindow.append(1 / delta)
                if fpsWindow.count > 30 { fpsWindow.removeFirst() }
                fps = fpsWindow.reduce(0, +) / Double(fpsWindow.count)
            }
        }

        let snapshot = currentTracks
        let blobTotal = blobs.count
        let outcome = result.outcome

        DispatchQueue.main.async {
            self.tracks = snapshot
            self.blobCount = blobTotal
            self.status = result.status
            self.notice = result.notice
            if fps > 0 { self.analysisFPS = fps }
            if let outcome, scoring { self.onOutcome?(outcome) }
        }
    }
}

/// Live preview. Stores its layer on the controller so taps can be converted.
struct CameraPreview: UIViewRepresentable {
    let controller: CameraController

    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.videoPreviewLayer.session = controller.session
        view.videoPreviewLayer.videoGravity = .resizeAspectFill
        controller.previewLayer = view.videoPreviewLayer
        controller.applyRotation()
        return view
    }

    func updateUIView(_ uiView: PreviewView, context: Context) {
        controller.previewLayer = uiView.videoPreviewLayer
    }

    final class PreviewView: UIView {
        override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
        var videoPreviewLayer: AVCaptureVideoPreviewLayer {
            layer as! AVCaptureVideoPreviewLayer
        }
    }
}
