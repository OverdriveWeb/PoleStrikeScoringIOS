import Foundation

/// Paste your Supabase project details here once, and every copy of the app you
/// hand out is already wired to the shared pool — nothing for a new user to set
/// up, no keys to type on a phone.
///
/// The anon key belongs in client code. That is what it is for: it grants only
/// what your row-level security policies allow, which here is "insert a row of
/// fourteen numbers" and "read the pool". It is not a secret in the way a
/// service-role key is — never put a service-role key in an app.
enum CloudDefaults {

    /// e.g. "https://abcdefghijklm.supabase.co"
    static let url = ""

    /// Project Settings → API → Project API keys → **anon public**
    static let anonKey = ""

    /// Share by default. Users can still turn it off in Settings.
    static let sharingOnByDefault = true

    static var isBaked: Bool {
        !url.trimmingCharacters(in: .whitespaces).isEmpty
            && !anonKey.trimmingCharacters(in: .whitespaces).isEmpty
    }

    static var config: CloudConfig {
        CloudConfig(url: url, anonKey: anonKey, sharing: sharingOnByDefault)
    }
}
