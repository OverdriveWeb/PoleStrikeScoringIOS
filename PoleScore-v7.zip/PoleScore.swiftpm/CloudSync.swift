import Foundation

/// Shared learning across every install.
///
/// What crosses the network is deliberately tiny and impersonal: fourteen
/// numbers describing the physics of a play — heights, speeds, frame counts —
/// plus which call was correct. No video, no images, no location, no account,
/// no way back to a person. A row looks like `[1, 5, 0, 0.02, 0.41, ...] -> 0`.
///
/// The reason this transfers across courts at all: every feature is normalized
/// against *that user's own* calibration. A height of 0.02 means "just above my
/// ground line" whether the court is a backyard or a beach. Raw pixels would be
/// useless between users; calibrated ratios are comparable.
struct CloudConfig: Codable, Equatable {
    var url: String = ""
    var anonKey: String = ""
    var sharing = false

    var isConfigured: Bool {
        !url.trimmingCharacters(in: .whitespaces).isEmpty
            && !anonKey.trimmingCharacters(in: .whitespaces).isEmpty
    }
}

struct SyncReport {
    var uploaded = 0
    var downloaded = 0
    var poolSize = 0
    var error: String?
}

/// Supabase REST client. No server code to deploy — a table and two policies.
/// See `supabase-schema.sql`.
actor CloudSync {
    private var config = CloudConfig()
    private var uploadedIds = Set<String>()

    private let deviceKey = "polescore.deviceId"
    private let uploadedKey = "polescore.uploaded"

    /// Random per install, so rows can be de-duplicated and a device can skip
    /// its own contributions on download. Not tied to anything about you.
    private var deviceId: String {
        if let existing = UserDefaults.standard.string(forKey: deviceKey) { return existing }
        let fresh = UUID().uuidString
        UserDefaults.standard.set(fresh, forKey: deviceKey)
        return fresh
    }

    init() {
        if let stored = UserDefaults.standard.stringArray(forKey: uploadedKey) {
            uploadedIds = Set(stored)
        }
    }

    func update(config: CloudConfig) {
        self.config = config
    }

    private struct Row: Codable {
        var id: String
        var device: String
        var features: [Double]
        var label: Int
        var rule_call: Int
        var app_version: String
    }

    private func endpoint(_ path: String) -> URL? {
        let base = config.url.trimmingCharacters(in: .whitespaces).hasSuffix("/")
            ? String(config.url.dropLast())
            : config.url.trimmingCharacters(in: .whitespaces)
        return URL(string: "\(base)/rest/v1/\(path)")
    }

    private func request(_ url: URL, method: String) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue(config.anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(config.anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 20
        return request
    }

    /// Push anything this device has learned that has not been shared yet, then
    /// pull back what everyone else has contributed.
    func sync(local: [TrainingExample], poolLimit: Int = 800) async -> (report: SyncReport, pool: [TrainingExample]) {
        var report = SyncReport()
        guard config.isConfigured, config.sharing else {
            report.error = "Sharing is off or not configured."
            return (report, [])
        }

        // --- upload ---------------------------------------------------------
        let pending = local.filter { !uploadedIds.contains($0.id) }
        if !pending.isEmpty, let url = endpoint("training_examples") {
            let rows = pending.map {
                Row(id: $0.id,
                    device: deviceId,
                    features: $0.features.vector,
                    label: $0.label,
                    rule_call: $0.ruleCall,
                    app_version: "1.0")
            }
            var request = request(url, method: "POST")
            request.setValue("return=minimal,resolution=ignore-duplicates", forHTTPHeaderField: "Prefer")
            request.httpBody = try? JSONEncoder().encode(rows)
            do {
                let (_, response) = try await URLSession.shared.data(for: request)
                if let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) {
                    report.uploaded = rows.count
                    uploadedIds.formUnion(rows.map(\.id))
                    UserDefaults.standard.set(Array(uploadedIds), forKey: uploadedKey)
                } else if let http = response as? HTTPURLResponse {
                    report.error = "Upload failed (HTTP \(http.statusCode))."
                }
            } catch {
                report.error = "Upload failed: \(error.localizedDescription)"
            }
        }

        // --- download -------------------------------------------------------
        guard var components = URLComponents(string: endpoint("training_examples")?.absoluteString ?? "") else {
            return (report, [])
        }
        components.queryItems = [
            URLQueryItem(name: "select", value: "id,features,label,rule_call"),
            URLQueryItem(name: "order", value: "created_at.desc"),
            URLQueryItem(name: "limit", value: String(poolLimit)),
            // Skip our own rows: they are already in the local set, and counting
            // them twice would quietly overweight this one court.
            URLQueryItem(name: "device", value: "neq.\(deviceId)")
        ]
        guard let downloadURL = components.url else { return (report, []) }

        do {
            let (data, response) = try await URLSession.shared.data(for: request(downloadURL, method: "GET"))
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                report.error = report.error ?? "Download failed."
                return (report, [])
            }
            let rows = try JSONDecoder().decode([DownloadRow].self, from: data)
            let pool: [TrainingExample] = rows.compactMap { row in
                guard row.features.count == PlayFeatures.count else { return nil }
                var features = PlayFeatures()
                let v = row.features
                features.bottleKnocked = v[0]; features.bottleGroundFrames = v[1]
                features.bottleCaughtFrames = v[2]; features.bottleFinalHeight = v[3]
                features.bottlePeakSpeed = v[4]; features.discSeen = v[5]
                features.discGroundFrames = v[6]; features.discCaughtFrames = v[7]
                features.discFinalHeight = v[8]; features.discPeakSpeed = v[9]
                features.discPoleFrames = v[10]; features.duration = v[11]
                features.quality = v[12]; features.occlusion = v[13]
                return TrainingExample(id: row.id, features: features, label: row.label,
                                       ruleCall: row.rule_call, at: Date())
            }
            report.downloaded = pool.count
            report.poolSize = pool.count
            return (report, pool)
        } catch {
            report.error = report.error ?? "Download failed: \(error.localizedDescription)"
            return (report, [])
        }
    }

    private struct DownloadRow: Codable {
        var id: String
        var features: [Double]
        var label: Int
        var rule_call: Int
    }
}
