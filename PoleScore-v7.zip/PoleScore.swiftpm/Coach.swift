import Foundation

/// In-app assistant.
///
/// Deliberately not a chatbot: there is no language model on the device, and
/// pretending otherwise would mean inventing answers about your court. Instead
/// it reads what the app actually measured — live blob counts, the calls it
/// made, where you disagreed with it — and gives specific, checkable advice.
/// Every suggestion below is tied to a number the app can see.
struct CoachNote: Identifiable {
    enum Level { case good, warn, bad }
    var id = UUID()
    var level: Level
    var title: String
    var detail: String
}

enum Coach {

    /// Plain snapshot of the learning state. Taking a copy on the main actor and
    /// passing values keeps this function free of any actor isolation, which is
    /// what the compiler was objecting to.
    struct LearningSnapshot {
        var examples: Int
        var poolSize: Int
        var modelAccuracy: Double
        var ruleAgreement: Double
        var groundVsCaughtConfusions: Int
        var sharingConfigured: Bool
    }

    static func diagnose(blobCount: Int,
                         fps: Double,
                         calibrated: Bool,
                         mode: ScoringMode,
                         plays: [PlayRecord],
                         learning: LearningSnapshot) -> [CoachNote] {
        var notes: [CoachNote] = []

        // --- setup ---------------------------------------------------------
        if !calibrated {
            notes.append(CoachNote(level: .bad, title: "Court not marked",
                                   detail: "Tap the poles, bottles and ground line first. Nothing can be scored until the app knows where the ground is."))
        }

        switch blobCount {
        case 0:
            notes.append(CoachNote(level: .bad, title: "Nothing lit is visible",
                                   detail: "Lower the brightness threshold in Settings, or check the set is actually glowing and in frame."))
        case 1...2:
            notes.append(CoachNote(level: .warn, title: "Only \(blobCount) lit object found",
                                   detail: "Expect at least 3 — two bottles and a disc. Move back so both poles are in frame, or lower the threshold a little."))
        case 3...8:
            notes.append(CoachNote(level: .good, title: "\(blobCount) lit objects tracked",
                                   detail: "That is the right range for a two-pole court."))
        default:
            notes.append(CoachNote(level: .warn, title: "\(blobCount) lit objects — too many",
                                   detail: "Stray lights are being picked up. Raise the threshold, or get porch lights and phone screens out of frame."))
        }

        if fps > 0 && fps < 12 {
            notes.append(CoachNote(level: .warn, title: "Analysing at only \(Int(fps)) fps",
                                   detail: "Low light makes the camera itself slow down. Fast throws may be missed between frames."))
        }

        // --- what the calls look like --------------------------------------
        let recent = plays.suffix(20)
        if recent.count >= 5 {
            let dead = recent.filter { $0.banner.contains("dead") || $0.banner.contains("No score") }.count
            if Double(dead) / Double(recent.count) > 0.4 {
                notes.append(CoachNote(level: .warn, title: "Many plays resolving as dead throws",
                                       detail: "Usually the disc is not being tracked. Give the disc its own glow colour in Settings if your set allows, or lower the threshold."))
            }
        }

        // --- learning ------------------------------------------------------
        if learning.examples == 0 {
            notes.append(CoachNote(level: .warn, title: "It has not learned anything yet",
                                   detail: "Play a few throws in Ask-first mode. Every confirmation or correction becomes a training example from your own court."))
        } else if learning.examples < 8 {
            notes.append(CoachNote(level: .warn, title: "\(learning.examples) examples so far",
                                   detail: "Needs about 8 before the model starts influencing calls, and around 40 before it carries real weight."))
        } else {
            let rules = Int(learning.ruleAgreement * 100)
            let model = Int(learning.modelAccuracy * 100)
            notes.append(CoachNote(level: model >= rules ? .good : .warn,
                                   title: "Learned model: \(model)% vs rules \(rules)%",
                                   detail: model >= rules
                                   ? "The model now matches your calls at least as well as the fixed rules, and is being blended in."
                                   : "The fixed rules still agree with you more often. Keep correcting — or run Tune thresholds, which often helps faster than the model."))
        }

        if learning.poolSize == 0 && learning.examples >= 5 && !learning.sharingConfigured {
            notes.append(CoachNote(level: .warn, title: "Not sharing learning yet",
                                   detail: "Turning on shared learning in Settings pools corrections across every install, which is what makes a fresh phone start out accurate instead of naive."))
        }

        // --- the disagreements that matter ---------------------------------
        if learning.groundVsCaughtConfusions >= 3 {
            notes.append(CoachNote(level: .bad, title: "Confusing caught bottles with grounded ones",
                                   detail: "That is almost always a ground line in the wrong place. Recalibrate and tap exactly where each pole meets the grass — it is the measurement that separates 2 points from 3."))
        }

        if mode == .auto && learning.examples < 15 {
            notes.append(CoachNote(level: .warn, title: "Automatic mode with little history",
                                   detail: "It will score on its own before it has learned your court. Ask-first for a game or two is the safer trade."))
        }

        return notes
    }

    /// Plain-language explanation of a single call, from the evidence recorded
    /// at the time — not a guess after the fact.
    static func explain(_ play: PlayRecord) -> String {
        var lines = ["Called: \(play.banner)", "Confidence: \(Int(play.confidence * 100))%"]
        lines.append(contentsOf: play.reasons.map { "· \($0)" })
        if !play.applied {
            lines.append("This one did not change the score.")
        }
        return lines.joined(separator: "\n")
    }

    struct Question: Identifiable {
        var id: String { question }
        let question: String
        let answer: String
    }

    static let questions: [Question] = [
        Question(question: "Why did it score 2 instead of 3?",
                 answer: "It decided the bottle was caught rather than grounded. A catch means the bottle stopped moving above your calibrated ground line. If that is wrong, the ground line is usually too high — recalibrate, or correct the call so it learns."),
        Question(question: "Why is it slow to call a play?",
                 answer: "Every observation has to hold for several consecutive frames before it counts. That is deliberate: single-frame decisions produce phantom scores. You can lower the confirm frames with Tune thresholds once it has examples to tune against."),
        Question(question: "It missed the throw entirely.",
                 answer: "A play can start two ways: the disc being tracked at speed, or a bottle leaving a pole top. If neither registered, the disc is probably not being detected — check the lit count on the game screen while holding the disc up."),
        Question(question: "Can I trust automatic mode?",
                 answer: "Only once you have watched it agree with you for a full game. Ask-first costs one tap per play and gives the model the corrections it needs. Tap-only always works regardless of what the camera does.")
    ]
}
