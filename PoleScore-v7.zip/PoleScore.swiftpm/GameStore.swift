import Foundation
import SwiftUI

enum ScoringMode: String, Codable, CaseIterable {
    case auto, assist, manual

    var title: String {
        switch self {
        case .auto: return "Automatic"
        case .assist: return "Ask first"
        case .manual: return "Tap only"
        }
    }

    var detail: String {
        switch self {
        case .auto: return "Confident calls apply on their own, with an undo window."
        case .assist: return "Every call waits for a tap. Nothing moves the score by itself."
        case .manual: return "Detection runs for the overlay only. You score with the pad."
        }
    }
}

struct PlayRecord: Identifiable, Codable {
    var id: String
    var banner: String
    var confidence: Double
    var applied: Bool
    var delta: Scores
    var thrower: TeamId
    var reasons: [String]
    var at: Date
}

/// Single source of truth for the app. Persists to UserDefaults as JSON, which
/// is plenty for a scoreboard and keeps the whole thing dependency-free.
@MainActor
final class GameStore: ObservableObject {
    @Published var scores = Scores()
    @Published var thrower: TeamId = .A
    @Published var plays: [PlayRecord] = []
    @Published var winner: TeamId?
    @Published var pending: PlayOutcome?
    @Published var undoUntil: Date?

    @Published var court: Court = .placeholder
    @Published var calibrated = false

    @Published var mode: ScoringMode = .assist { didSet { save() } }
    @Published var rules: RuleSet = .beersbee { didSet { save() } }
    @Published var colors: GlowColors = .unset { didSet { save() } }
    @Published var threshold: Double = 0.62 { didSet { save() } }
    @Published var confidence: Double = 0.85 { didSet { save() } }
    @Published var teamAName = "Team A" { didSet { save() } }
    @Published var teamBName = "Team B" { didSet { save() } }
    @Published var showDebug = false { didSet { save() } }
    /// Landscape with the charging port on the right. Adjustable because the
    /// sensor's native orientation is not the same on every device.
    @Published var rotation: Double = 0 { didSet { save() } }
    @Published var tuning = TunableConfig() { didSet { save() } }

    /// Set by the app so corrections can be turned into training examples.
    var learning: LearningStore?
    /// The play awaiting a correction, if you rejected a suggestion.
    @Published var correcting: PlayOutcome?

    private let defaults = UserDefaults.standard

    init() {
        load()
    }

    func name(_ team: TeamId) -> String { team == .A ? teamAName : teamBName }

    // MARK: - Scoring

    /// Blends the rule-based confidence with the learned model, weighted by how
    /// much evidence the model has actually earned. With no examples the model
    /// has no say at all, so learning can never make day one worse.
    func adjustedConfidence(for outcome: PlayOutcome) -> Double {
        guard let learning, learning.trust > 0 else { return outcome.confidence }
        let modelProbability = learning.model.probability(of: outcome.primaryClass, given: outcome.features)
        let t = learning.trust
        return outcome.confidence * (1 - t) + modelProbability * t
    }

    func handle(outcome: PlayOutcome) {
        var outcome = outcome
        outcome.confidence = adjustedConfidence(for: outcome)
        outcome.needsReview = outcome.confidence < confidence || outcome.events.contains(.deadThrow)

        let shouldApply = mode == .auto && !outcome.needsReview
        if shouldApply {
            apply(outcome: outcome)
        } else if mode != .manual {
            pending = outcome
        }
    }

    /// Confirming a call is agreement, and agreement is a training example just
    /// as much as a correction is.
    func confirm(outcome: PlayOutcome) {
        learning?.record(features: outcome.features, label: outcome.primaryClass, ruleCall: outcome.primaryClass)
        apply(outcome: outcome)
    }

    /// Rejecting opens the correction pad; whatever you tap becomes the label.
    func reject(outcome: PlayOutcome) {
        correcting = outcome
        pending = nil
    }

    func correct(to event: ScoreEvent) {
        guard let outcome = correcting else { return }
        let label = PlayClass.from(event)
        learning?.record(features: outcome.features, label: label, ruleCall: outcome.primaryClass)
        correcting = nil
        if event != .deadThrow {
            var corrected = outcome
            corrected.events = [event]
            apply(outcome: corrected)
        }
    }

    func cancelCorrection() {
        correcting = nil
    }

    func apply(outcome: PlayOutcome) {
        let result = RulesEngine.apply(outcome.events, thrower: outcome.thrower, to: scores, rules: rules)
        scores = result.scores
        winner = result.winner
        plays.append(PlayRecord(
            id: outcome.id,
            banner: result.banner,
            confidence: outcome.confidence,
            applied: true,
            delta: result.delta,
            thrower: outcome.thrower,
            reasons: outcome.reasons,
            at: Date()
        ))
        pending = nil
        undoUntil = Date().addingTimeInterval(8)
        thrower = thrower.other
    }

    func scoreManually(_ event: ScoreEvent) {
        let result = RulesEngine.apply([event], thrower: thrower, to: scores, rules: rules)
        scores = result.scores
        winner = result.winner
        plays.append(PlayRecord(
            id: "manual_\(UUID().uuidString)",
            banner: result.banner,
            confidence: 1,
            applied: true,
            delta: result.delta,
            thrower: thrower,
            reasons: ["Scored by tap"],
            at: Date()
        ))
        undoUntil = Date().addingTimeInterval(8)
        thrower = thrower.other
    }

    func discardPending() {
        pending = nil
    }

    func undoLast() {
        guard let last = plays.lastIndex(where: { $0.applied }) else { return }
        let play = plays[last]
        scores.A = max(0, scores.A - play.delta.A)
        scores.B = max(0, scores.B - play.delta.B)
        plays[last].applied = false
        plays[last].banner += " (undone)"
        winner = nil
        undoUntil = nil
        thrower = thrower.other
    }

    func newGame() {
        scores = Scores()
        plays = []
        winner = nil
        pending = nil
        undoUntil = nil
        thrower = .A
    }

    // MARK: - Persistence

    private struct Saved: Codable {
        var court: Court?
        var calibrated: Bool
        var mode: ScoringMode
        var rulesId: String
        var colors: GlowColors
        var threshold: Double
        var confidence: Double
        var teamAName: String
        var teamBName: String
        var showDebug: Bool
        var rotation: Double?
        var tuning: TunableConfig?
    }

    func save() {
        let saved = Saved(
            court: calibrated ? court : nil,
            calibrated: calibrated,
            mode: mode,
            rulesId: rules.id,
            colors: colors,
            threshold: threshold,
            confidence: confidence,
            teamAName: teamAName,
            teamBName: teamBName,
            showDebug: showDebug,
            rotation: rotation,
            tuning: tuning
        )
        if let data = try? JSONEncoder().encode(saved) {
            defaults.set(data, forKey: "polescore.state")
        }
    }

    private func load() {
        guard let data = defaults.data(forKey: "polescore.state"),
              let saved = try? JSONDecoder().decode(Saved.self, from: data) else { return }
        if let court = saved.court {
            self.court = court
            calibrated = saved.calibrated
        }
        mode = saved.mode
        rules = RuleSet.presets.first { $0.id == saved.rulesId } ?? .beersbee
        colors = saved.colors
        threshold = saved.threshold
        confidence = saved.confidence
        teamAName = saved.teamAName
        teamBName = saved.teamBName
        showDebug = saved.showDebug
        rotation = saved.rotation ?? 0
        tuning = saved.tuning ?? TunableConfig()
    }

    func saveCourt(_ court: Court) {
        self.court = court
        calibrated = true
        save()
    }
}
