import Foundation

struct GlowColors: Codable, Equatable {
    var disc: Double?
    var bottle: Double?
    var pole: Double?

    static let unset = GlowColors(disc: nil, bottle: nil, pole: nil)
}

/// Decides what each lit blob *is*.
///
/// Two routes, in order of preference:
///   1. Colour — if the disc and bottles glow differently, hue matching is
///      decisive and survives crossings and occlusion.
///   2. Geometry and motion — poles come from the calibration, a bottle is only
///      claimed while it sits at its own pole top (a tight radius, which is what
///      stops a disc flying past from being mistaken for it), then tracked
///      loosely as it falls. Whatever is left and moving is the disc.
///
/// Route 2 assumes frame-to-frame continuity, which is exactly what the camera
/// provides at 30fps.
final class GlowClassifier {
    var colors: GlowColors = .unset
    var hueTolerance = 32.0
    var minSaturation = 0.22
    var minArea = 0.00015
    var maxArea = 0.09
    var poleAspect = 2.6
    var restRadius = 0.075
    var maxBottleDistance = 0.42
    var colorConfidence = 0.95
    var geometryConfidence = 0.82

    private var memory: [Side: Pt] = [:]
    private var knocked: [Side: Bool] = [.left: false, .right: false]
    private var lastDisc: Pt?

    func reset() {
        memory = [:]
        knocked = [.left: false, .right: false]
        lastDisc = nil
    }

    func classify(blobs: [Blob], court: Court) -> [Detection] {
        var detections: [Detection] = []

        // Poles always come from the calibration: they never move, and a lit
        // pole is a long streak that would otherwise swallow the bottle on top.
        for side in [Side.left, .right] {
            let top = court.poleTop(side)
            let base = court.poleBase(side)
            detections.append(Detection(
                label: .pole(side),
                score: geometryConfidence,
                box: Box(x: top.x - 0.012, y: top.y, w: 0.024, h: max(0.02, base.y - top.y))
            ))
        }

        let usable = blobs.filter { $0.area >= minArea && $0.area <= maxArea && !looksLikePole($0, court: court) }
        var used = Set<Int>()

        // --- bottles -------------------------------------------------------
        let bottleCandidates = usable.enumerated().filter { _, blob in
            if let target = colors.bottle { return matches(blob, target) }
            if let discHue = colors.disc { return !matches(blob, discHue) }
            return true
        }

        struct Pair { var side: Side; var index: Int; var cost: Double }
        var pairs: [Pair] = []
        for (index, blob) in bottleCandidates {
            for side in [Side.left, .right] {
                let reference = memory[side] ?? court.poleTop(side)
                let radius = (knocked[side] ?? false) ? maxBottleDistance : restRadius
                let cost = distance(blob.box.center, reference)
                if cost <= radius { pairs.append(Pair(side: side, index: index, cost: cost)) }
            }
        }
        pairs.sort { $0.cost < $1.cost }

        var takenSides = Set<Side>()
        for pair in pairs {
            if takenSides.contains(pair.side) || used.contains(pair.index) { continue }
            takenSides.insert(pair.side)
            used.insert(pair.index)
            let blob = usable[pair.index]
            memory[pair.side] = blob.box.center
            detections.append(Detection(
                label: .bottle(pair.side),
                score: colors.bottle != nil ? colorConfidence : geometryConfidence,
                box: blob.box
            ))
            if court.isOnPole(pair.side, blob.box) {
                memory[pair.side] = court.poleTop(pair.side)
                knocked[pair.side] = false
            } else {
                knocked[pair.side] = true
            }
        }

        // --- disc ----------------------------------------------------------
        let remaining = usable.enumerated().filter { !used.contains($0.offset) }.map { $0.element }
        if let disc = pickDisc(remaining) {
            detections.append(disc)
        }

        return detections
    }

    private func matches(_ blob: Blob, _ target: Double) -> Bool {
        guard blob.saturation >= minSaturation else { return false }
        return hueDistance(blob.hue, target) <= hueTolerance
    }

    private func looksLikePole(_ blob: Blob, court: Court) -> Bool {
        if let poleHue = colors.pole, matches(blob, poleHue) { return true }
        guard blob.box.aspect >= poleAspect else { return false }
        let c = blob.box.center
        let nearPole = min(abs(c.x - court.leftTop.x), abs(c.x - court.rightTop.x))
        return nearPole < 0.06
    }

    private func pickDisc(_ remaining: [Blob]) -> Detection? {
        guard !remaining.isEmpty else { return nil }

        if let target = colors.disc {
            guard let matched = remaining.filter({ matches($0, target) }).max(by: { $0.brightness < $1.brightness }) else { return nil }
            lastDisc = matched.box.center
            return Detection(label: .disc, score: colorConfidence, box: matched.box)
        }

        // No colour to go on: prefer the blob nearest where the disc was last
        // frame, then the roundest one.
        let scored = remaining.min { a, b in
            cost(a) < cost(b)
        }
        guard let best = scored else { return nil }
        lastDisc = best.box.center
        return Detection(label: .disc, score: geometryConfidence, box: best.box)
    }

    private func cost(_ blob: Blob) -> Double {
        let continuity = lastDisc.map { distance(blob.box.center, $0) } ?? 1
        let roundness = abs(1 - blob.box.w / max(blob.box.h, 1e-6))
        return continuity * 2 + roundness
    }
}
