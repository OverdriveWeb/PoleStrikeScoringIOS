import SwiftUI
import UIKit

struct LiveGameView: View {
    @EnvironmentObject var store: GameStore
    @EnvironmentObject var camera: CameraController
    @State private var now = Date()

    private let tick = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            if camera.authorized {
                CameraPreview(controller: camera).ignoresSafeArea()
            } else {
                Theme.field.ignoresSafeArea()
            }

            if store.showDebug {
                GeometryReader { geo in
                    DebugOverlay(tracks: camera.tracks, court: store.court, size: geo.size)
                }
                .ignoresSafeArea()
                .allowsHitTesting(false)
            }

            VStack(alignment: .leading, spacing: 0) {
                topBar
                Spacer()
                scoreboard
                Spacer()
                bottomBar
            }
            .padding(16)
        }
        .background(Theme.field)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.hidden, for: .navigationBar)
        .onReceive(tick) { now = $0 }
        .onAppear {
            camera.court = store.court
            camera.courtCalibrated = store.calibrated
            camera.classifier.colors = store.colors
            camera.threshold = store.threshold
            camera.machine.config.confidenceThreshold = store.confidence
            camera.machine.applyTuning(store.tuning)
            camera.rotation = store.rotation
            camera.scoringEnabled = store.mode != .manual
            camera.onOutcome = { outcome in store.handle(outcome: outcome) }
            camera.resetTracking()
            camera.start()
            UIApplication.shared.isIdleTimerDisabled = true
        }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
            camera.stop()
        }
        .onChange(of: store.calibrated) { _, new in camera.courtCalibrated = new }
        .onChange(of: store.court) { _, new in camera.court = new }
    }

    private var topBar: some View {
        HStack(spacing: 12) {
            HStack(spacing: 8) {
                Circle().fill(statusColor).frame(width: 8, height: 8)
                Text(camera.status.text).font(.caption.weight(.bold)).kerning(1.2)
                Text("\(Int(camera.analysisFPS)) fps · \(camera.blobCount) lit")
                    .font(.caption.monospaced()).foregroundStyle(Theme.muted)
            }
            .padding(.horizontal, 12).padding(.vertical, 6)
            .background(Capsule().fill(Theme.panel.opacity(0.85)))
            .overlay(Capsule().stroke(statusColor, lineWidth: 1.5))
            .foregroundStyle(statusColor)

            Text(store.mode.title.uppercased())
                .font(.caption.weight(.bold)).kerning(1.4)
                .foregroundStyle(Theme.muted)

            Spacer()
        }
    }

    private var scoreboard: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .top, spacing: 18) {
                teamColumn(.A)
                Text("/").font(.system(size: 60, weight: .heavy)).foregroundStyle(Theme.edge)
                teamColumn(.B)
            }
            if let notice = camera.notice {
                Text(notice)
                    .font(.headline).foregroundStyle(Theme.flag)
                    .padding(8)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Theme.panel.opacity(0.9)))
            }
            if let winner = store.winner {
                Text("\(store.name(winner)) wins")
                    .font(.title.weight(.bold)).foregroundStyle(Theme.disc)
            }
        }
    }

    private func teamColumn(_ team: TeamId) -> some View {
        VStack(spacing: 2) {
            Text("\(store.scores[team])")
                .font(.system(size: 96, weight: .heavy))
                .monospacedDigit()
                .foregroundStyle(Theme.teamColor(team))
                .shadow(color: .black.opacity(0.8), radius: 8)
            Text(store.name(team).uppercased())
                .font(.caption.weight(.bold)).kerning(2)
                .foregroundStyle(store.thrower == team ? Theme.chalk : Theme.muted)
            Capsule()
                .fill(store.thrower == team ? Theme.teamColor(team) : Color.clear)
                .frame(width: 46, height: 4)
        }
    }

    private var bottomBar: some View {
        VStack(spacing: 10) {
            if let correcting = store.correcting {
                CorrectionPad(outcome: correcting)
            } else if let pending = store.pending, store.mode != .manual {
                ConfirmCard(outcome: pending)
            }
            if store.mode == .manual {
                ManualPad()
            }
            if let until = store.undoUntil, until > now {
                HStack {
                    Text(store.plays.last?.banner ?? "Scored")
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(2)
                    Spacer()
                    Button("Undo") { store.undoLast() }
                        .font(.headline)
                        .foregroundStyle(Theme.flag)
                        .padding(.horizontal, 18).padding(.vertical, 8)
                        .overlay(Capsule().stroke(Theme.flag, lineWidth: 1.5))
                }
                .padding(12)
                .background(RoundedRectangle(cornerRadius: 12).fill(Theme.panel))
            }

            HStack(spacing: 10) {
                Button("Undo") { store.undoLast() }
                    .buttonStyle(.bordered).tint(Theme.flag)
                Button(camera.running ? "Pause" : "Resume") {
                    camera.running ? camera.stop() : camera.start()
                }
                .buttonStyle(.bordered)
                if camera.status == .resetBottle {
                    Button("Bottle is back on") { camera.machine.confirmBottleReset() }
                        .buttonStyle(.borderedProminent).tint(Theme.disc)
                }
                Spacer()
                Button("New game") { store.newGame() }
                    .buttonStyle(.bordered)
            }
            .font(.subheadline.weight(.semibold))
        }
    }

    private var statusColor: Color {
        switch camera.status {
        case .watching, .paused: return Theme.muted
        case .trackingDisc: return Theme.disc
        case .scoringPlay: return Theme.glass
        case .lowConfidence, .resetBottle: return Theme.flag
        }
    }
}

/// Assist mode: the app proposes, you decide. Two large targets, no reading
/// beyond the banner.
struct ConfirmCard: View {
    @EnvironmentObject var store: GameStore
    let outcome: PlayOutcome

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(outcome.events.map(\.shortLabel).joined(separator: " + "))
                    .font(.headline)
                Text("\(Int(outcome.confidence * 100))% confidence · \(outcome.reasons.first ?? "")")
                    .font(.caption.monospaced())
                    .foregroundStyle(Theme.muted)
                    .lineLimit(2)
            }
            Spacer()
            Button("No") { store.reject(outcome: outcome) }
                .buttonStyle(.bordered)
            Button("Score it") { store.confirm(outcome: outcome) }
                .buttonStyle(.borderedProminent).tint(Theme.disc)
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 12).fill(Theme.panel))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Theme.disc, lineWidth: 1.5))
    }
}

/// The floor under everything else: whatever the camera does, the game stays
/// scorable with two taps.
struct ManualPad: View {
    @EnvironmentObject var store: GameStore

    private struct PadKey: Identifiable {
        let id: ScoreEvent
        let points: Int
    }

    private var scoringEvents: [PadKey] {
        store.rules.events
            .filter { $0.value.points > 0 }
            .map { PadKey(id: $0.key, points: $0.value.points) }
            .sorted { $0.points < $1.points }
    }

    var body: some View {
        HStack(spacing: 8) {
            Button {
                store.thrower = store.thrower.other
            } label: {
                VStack(spacing: 2) {
                    Text("THROWING").font(.caption2.weight(.bold)).kerning(1.2).foregroundStyle(Theme.muted)
                    Text(store.name(store.thrower)).font(.headline)
                }
                .frame(minWidth: 104)
                .padding(.vertical, 10)
            }
            .buttonStyle(.plain)
            .background(RoundedRectangle(cornerRadius: 12).fill(Theme.panel))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Theme.edge, lineWidth: 1.5))

            ForEach(scoringEvents) { key in
                Button {
                    store.scoreManually(key.id)
                } label: {
                    VStack(spacing: 2) {
                        Text("+\(key.points)").font(.title2.weight(.heavy)).monospacedDigit()
                            .foregroundStyle(Theme.disc)
                        Text(key.id.shortLabel).font(.caption2.weight(.bold))
                            .foregroundStyle(Theme.chalk)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                }
                .buttonStyle(.plain)
                .background(RoundedRectangle(cornerRadius: 12).fill(Theme.panel))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Theme.disc, lineWidth: 1.5))
            }
        }
    }
}

/// Developer view only — normal play shows a clean preview.
struct DebugOverlay: View {
    let tracks: [Track]
    let court: Court
    let size: CGSize

    var body: some View {
        ZStack(alignment: .topLeading) {
            Path { path in
                path.move(to: CGPoint(x: court.groundA.x * size.width, y: court.groundA.y * size.height))
                path.addLine(to: CGPoint(x: court.groundB.x * size.width, y: court.groundB.y * size.height))
            }
            .stroke(Theme.flag.opacity(0.7), lineWidth: 1.5)

            ForEach(tracks) { track in
                let rect = CGRect(x: track.box.x * size.width,
                                  y: track.box.y * size.height,
                                  width: track.box.w * size.width,
                                  height: track.box.h * size.height)
                Rectangle()
                    .stroke(color(track.label), lineWidth: 1.5)
                    .frame(width: rect.width, height: rect.height)
                    .position(x: rect.midX, y: rect.midY)
                Text("\(track.label.rawValue) #\(track.id)")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundStyle(color(track.label))
                    .position(x: rect.midX, y: max(8, rect.minY - 8))
            }
        }
    }

    private func color(_ label: Label) -> Color {
        switch label {
        case .disc: return Theme.disc
        case .leftBottle, .rightBottle: return Theme.glass
        case .leftPole, .rightPole: return Theme.chalk
        case .player: return Theme.flag
        }
    }
}
