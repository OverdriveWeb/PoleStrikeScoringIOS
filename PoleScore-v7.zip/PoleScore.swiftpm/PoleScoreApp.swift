import SwiftUI

@main
struct PoleScoreApp: App {
    @StateObject private var store = GameStore()
    @StateObject private var camera = CameraController()
    @StateObject private var learning = LearningStore()

    var body: some Scene {
        WindowGroup {
            HomeView()
                .environmentObject(store)
                .environmentObject(camera)
                .environmentObject(learning)
                .onAppear {
                    store.learning = learning
                    learning.autoSync(force: true)
                }
                .preferredColorScheme(.dark)
                .tint(Theme.disc)
        }
    }
}

struct HomeView: View {
    @EnvironmentObject var store: GameStore
    @EnvironmentObject var camera: CameraController

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Prop the phone.").font(.largeTitle.weight(.bold))
                        Text("Throw the disc.").font(.largeTitle.weight(.bold))
                        Text("It keeps score.").font(.largeTitle.weight(.bold)).foregroundStyle(Theme.disc)
                    }
                    .padding(.vertical, 8)

                    if !CameraController.hasCameraUsageDescription {
                        PanelCard {
                            SectionLabel(text: "Setup needed")
                            Text("Camera capability is missing")
                                .font(.headline).foregroundStyle(Theme.flag)
                            Text("In Swift Playgrounds, open App Settings, add the Camera capability with a "
                                 + "description, then run again. Tap-only scoring works without it.")
                                .font(.subheadline).foregroundStyle(Theme.muted)
                        }
                    }

                    PanelCard {
                        SectionLabel(text: "Rules")
                        Text(store.rules.name).font(.headline)
                        Text(store.rules.detail).font(.subheadline).foregroundStyle(Theme.muted)
                    }

                    PanelCard {
                        SectionLabel(text: "Court")
                        Text(store.calibrated ? "Calibrated and ready" : "Not calibrated yet").font(.headline)
                        Text(store.calibrated
                             ? "Scoring uses the saved pole, bottle and ground positions. Recalibrate if the phone moves."
                             : "Mark the poles, bottles and ground line before the first throw.")
                            .font(.subheadline).foregroundStyle(Theme.muted)
                        NavigationLink {
                            CalibrationView()
                        } label: {
                            Text(store.calibrated ? "Recalibrate" : "Set up the court")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .overlay(Capsule().stroke(Theme.edge, lineWidth: 1.5))
                        }
                        .buttonStyle(.plain)
                    }

                    NavigationLink {
                        LiveGameView()
                    } label: {
                        Text("Start game")
                            .font(.headline)
                            .foregroundStyle(Theme.field)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(Capsule().fill(Theme.disc))
                    }
                    .buttonStyle(.plain)

                    HStack {
                        NavigationLink("Settings") { SettingsView() }
                        Spacer()
                        NavigationLink("Coach") { CoachView() }
                        Spacer()
                        NavigationLink("History") { HistoryView() }
                    }
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Theme.muted)
                    .padding(.top, 4)
                }
                .padding(20)
            }
            .background(Theme.field)
            .navigationTitle("PoleScore")
            .navigationBarTitleDisplayMode(.inline)
        }
        .task {
            await camera.requestAccess()
        }
    }
}
