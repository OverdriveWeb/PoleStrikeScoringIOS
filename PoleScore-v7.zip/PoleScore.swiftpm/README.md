# PoleScore for Swift Playgrounds

Live camera scoring for a glow-in-the-dark Strike Pole / Beersbee set, built to
run on your iPad or iPhone straight from Swift Playgrounds — **no Apple
Developer account, no cloud build, no expiry to work around.**

## Getting it running

1. Download the zip on the device, then unzip it in the **Files** app (long
   press → Uncompress).
2. Tap `PoleScore.swiftpm`. It opens in Swift Playgrounds.
3. **Turn on camera access before the first run.** Tap the app-settings control
   in Playgrounds (the ⚙/app icon at the top), find **Capabilities**, add
   **Camera**, and give it a description like "Watches the court to score
   plays." Without this the app builds fine but the preview stays black.
4. Press ▶ to run. Playgrounds installs it to your home screen, where it runs
   like any other app.

If it ever stops launching from the home screen, open it in Playgrounds and run
it once more.

## At the court

1. Prop the device sideways, 15–30 feet back, both poles in frame.
2. **Set up the court** → tap six points: top of each pole, each bottle, and the
   ground at each pole.
3. **Start game.**

It opens in **Ask first** mode: the app watches and calls what it sees, and
waits for one tap before the score moves. Switch to Automatic once you've
watched it agree with you for a game. **Tap only** turns it into a plain
scoreboard with big buttons — always available, works regardless of the camera.

## Why there is no neural network here

For a lit set on a dark field, a model is the wrong tool. The glowing objects
are the only bright pixels, so finding them is a brightness threshold — no
training data, no download, about twenty times cheaper per frame, and it handles
the case a general detector is worst at: a spinning disc in flight, which blurs
into a mess for a model but stays an obvious bright streak here.

Colour does the rest. If your disc and bottles glow differently, set the hues in
Settings and identification becomes near-decisive. For a single-colour set the
app falls back to position and motion: poles come from your calibration, a
bottle is only claimed while it sits at its own pole top, then tracked loosely
as it falls, and whatever is left and moving is the disc.

## Catch vs ground

This is what your rules hinge on. In the dark there are no visible players, so a
catch is recognised by **height**: an object that stops moving well above the
calibrated ground line is being held; one that stops at the line is not.

| What happened | How it is recognised |
|---|---|
| Disc caught | Disc was moving, then stops **above** the ground line |
| Disc hits the ground | Disc reaches the ground line and settles |
| Bottle knocked, then caught | Bottle leaves the pole top, then stops **above** the line |
| Bottle knocked, hits ground | Bottle leaves the pole top and reaches the line |

One subtlety that caused a real bug during development: the first moments of a
bottle toppling look *exactly* like a catch — high up and barely moving. So a
catch requires motion **followed by** stillness. An object that never moved fast
during a play can never be called caught.

Which is why the **ground line matters more than anything else you tap**. Put it
where the poles actually meet the grass.

## Camera orientation

Set for the device lying long ways with the **charging port on the right**. If
the picture is upside down or sideways, go to **Settings → Camera orientation**
and step through 0/90/180/270 until it matches the court. 180° is the default
because it suits most devices, but the sensor's native "up" is not the same on
every model.

The rotation applies to the analysis buffer as well as the preview, so the debug
overlay and the detector never disagree with what you see.

## How it gets better

Three separate mechanisms, in the order they start helping:

**1. Your corrections become training data.** In Ask-first mode, confirming a
call records agreement; rejecting it opens a pad where you tap what actually
happened. Either way the app stores a feature vector — heights, speeds, how many
frames each observation held, how much was occluded — with your answer as the
label. That data is from your court, your set, your lighting.

**2. Threshold tuning (evolutionary).** Coach → **Tune thresholds from my
corrections** runs a mutation-and-selection loop over the six numbers that decide
a call: catch height, settle gate, bottle displacement, rest speed, pole
proximity, confirm frames. Fitness is how often a threshold set reproduces the
calls *you* made. Gradient descent is the wrong tool here — confirm frames is an
integer and the rules are hard comparisons with no derivative — but evolution
handles that fine and converges in under a second. **Needs about 8 examples**,
and usually helps first.

**3. A learned model.** A small neural network (14 inputs → 10 hidden → 6 calls)
trained by SGD on the same examples. Its opinion is blended into the confidence
score, weighted by how much evidence it has earned: at zero examples it has no
say at all, reaching meaningful weight around 40. It cannot make day one worse
than it already is.

Coach shows both numbers — how often the fixed rules matched you versus how often
the model does. If the model is not beating the rules yet, it says so.

## Learning across every install

Three mechanisms above make one phone better. This makes every phone better.

**Set it up once (about five minutes):**

1. Create a free project at supabase.com.
2. Open the **SQL editor**, paste in `supabase-schema.sql` from this folder, run it.
3. In **Project Settings → API**, copy the **Project URL** and the **anon public** key.
4. In the app: **Settings → Shared learning** → paste both, turn on **Share and
   receive learning**.
5. **Coach → Sync now.**

Every install using the same URL and key now contributes to and reads from one
pool. A phone installed tomorrow starts with everything learned so far instead of
starting naive — which is the whole point.

**What actually leaves the device:** fourteen numbers per play and the correct
call. A row is literally `[1, 5, 0, 0.02, 0.41, ...] -> 0`. No video, no images,
no location, no account, no name. There is no path from a row back to a person.

**Why it transfers between different courts at all:** every feature is normalized
against that user's own calibration. A bottle height of 0.02 means "just above my
ground line" whether the court is a backyard or a parking lot. Raw pixels would be
useless across users; calibrated ratios are directly comparable.

**Why more data is not automatically better — and how that is handled.** Other
people have different courts, different readings of the rules, and some will have
calibrated carelessly. So the app trains two models on every retrain: one on your
corrections alone, one on yours plus the pool. Both are scored on *your* data, and
it keeps whichever predicts your calls better. Coach tells you which one won.

The practical effect: pooled data does the heavy lifting when you have almost no
data of your own, and quietly loses influence as your own corrections accumulate.
Shared learning can help you a lot and is structurally prevented from making you
worse.

## Distributing it to other people

Worth knowing before you plan around it: **getting this app onto other people's
devices requires the $99/year Apple Developer Program**, through TestFlight or the
App Store. Swift Playgrounds can submit to the App Store, but the membership is
the gate — the same one we hit earlier. Nothing about the shared-learning setup
changes that; it just means the pool starts filling once other people actually
have the app.

## The Coach

Not a chatbot. There is no language model on the device, and inventing answers
about a court it cannot see would be worse than useless. What it does instead is
read what the app actually measured — live lit-object count, analysis frame rate,
the calls it made, where you disagreed — and give specific advice tied to those
numbers.

The most useful thing it does: if your corrections keep flipping *caught* and
*grounded* bottles, it tells you the ground line is in the wrong place. That is
the single most common calibration mistake, and it is worth exactly one point
per play.

## Tuning

Watch the "lit" count on the game screen — it tells you how many bright regions
are being found right now.

| Symptom | Fix |
|---|---|
| Nothing detected | Lower the brightness threshold in Settings |
| Stray lights detected | Raise the threshold; keep porch lights out of frame |
| Bottle and disc confused | Set different glow colours if your set has them |
| Score moves when it shouldn't | Switch to Ask first; check History for the evidence |
| Calls feel late | Normal — every event must hold for several frames before it counts |

## Honest limits

- Fading glow degrades detection. Recharge the set at halftime rather than
  dropping the threshold.
- A bottle landing behind a pole, hidden from the camera, can't be resolved —
  you get a low-confidence call flagged for review, which is the right answer.
- Keep the device still. Low light means longer exposures and more motion blur,
  so a rigid mount matters more at night than in daylight.
- Nothing is uploaded and no video is recorded. Frames are analysed and dropped.
