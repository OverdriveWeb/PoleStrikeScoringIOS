import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var store: GameStore
    @EnvironmentObject var camera: CameraController

    /// Key paths into tuples are not a thing in Swift, so ForEach needs a real
    /// Identifiable element here.
    private struct HueChoice: Identifiable {
        let id: String
        let hue: Double?
    }

    private let hues: [HueChoice] = [
        HueChoice(id: "Off", hue: nil),
        HueChoice(id: "Green", hue: 120),
        HueChoice(id: "Blue", hue: 210),
        HueChoice(id: "Pink", hue: 320),
        HueChoice(id: "Orange", hue: 30)
    ]

    @EnvironmentObject var learning: LearningStore

    var body: some View {
        Form {
            Section {
                Picker("Mode", selection: $store.mode) {
                    ForEach(ScoringMode.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                .pickerStyle(.segmented)
                Text(store.mode.detail).font(.footnote).foregroundStyle(Theme.muted)
            } header: {
                Text("How it keeps score")
            }

            Section {
                Picker("Rules", selection: Binding(
                    get: { store.rules.id },
                    set: { id in store.rules = RuleSet.presets.first { $0.id == id } ?? .beersbee }
                )) {
                    ForEach(RuleSet.presets) { Text($0.name).tag($0.id) }
                }
                Text(store.rules.detail).font(.footnote).foregroundStyle(Theme.muted)
            } header: {
                Text("Rules")
            }

            Section {
                hueRow("Disc", value: $store.colors.disc)
                hueRow("Bottles", value: $store.colors.bottle)
                hueRow("Poles", value: $store.colors.pole)
            } header: {
                Text("Glow colours")
            } footer: {
                Text("If your disc and bottles glow in different colours, set them — colour matching beats every other method. Leave them off for a single-colour set and the app works from position and motion instead.")
            }

            Section {
                VStack(alignment: .leading) {
                    Text("Brightness threshold: \(String(format: "%.2f", store.threshold))")
                    Slider(value: $store.threshold, in: 0.35...0.9)
                }
                VStack(alignment: .leading) {
                    Text("Confidence to auto-score: \(Int(store.confidence * 100))%")
                    Slider(value: $store.confidence, in: 0.5...0.99)
                }
                Toggle("Developer overlay", isOn: $store.showDebug)
            } header: {
                Text("Detection")
            } footer: {
                Text("Lower the threshold if the set is not being picked up; raise it if stray lights are. Watch the \"lit\" count on the game screen while you adjust.")
            }

            Section {
                Toggle("Share and receive learning", isOn: $learning.cloud.sharing)
                if CloudDefaults.isBaked {
                    HStack {
                        Text("Project")
                        Spacer()
                        Text("Built in").foregroundStyle(Theme.muted)
                    }
                } else {
                    TextField("Supabase project URL", text: $learning.cloud.url)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    SecureField("Supabase anon key", text: $learning.cloud.anonKey)
                    if learning.cloud.sharing && !learning.cloud.isConfigured {
                        Text("Both fields are needed before anything will sync.")
                            .font(.footnote).foregroundStyle(Theme.flag)
                    }
                }
            } header: {
                Text("Shared learning")
            } footer: {
                Text("Every install contributes anonymous play measurements and reads back the pool, so a new phone starts with everyone's experience instead of nothing. What leaves the device is fourteen numbers and the correct call — no video, no images, no identity. Run supabase-schema.sql in your project first.")
            }

            Section {
                Picker("Rotation", selection: $store.rotation) {
                    Text("0°").tag(0.0)
                    Text("90°").tag(90.0)
                    Text("180°").tag(180.0)
                    Text("270°").tag(270.0)
                }
                .pickerStyle(.segmented)
            } header: {
                Text("Camera orientation")
            } footer: {
                Text("Set for the device lying long ways with the charging port on the right. 0° suits most devices; if the preview is upside down or sideways, step through the others until the picture matches the court. Rotation applies to detection as well, so the overlay always lines up.")
            }

            Section {
                TextField("Team A", text: $store.teamAName)
                TextField("Team B", text: $store.teamBName)
            } header: {
                Text("Teams")
            }
        }
        .navigationTitle("Settings")
        .onChange(of: store.colors) { _, new in camera.classifier.colors = new }
        .onChange(of: store.threshold) { _, new in camera.threshold = new }
        .onChange(of: store.confidence) { _, new in camera.machine.config.confidenceThreshold = new }
        .onChange(of: store.mode) { _, new in camera.scoringEnabled = new != .manual }
        .onChange(of: store.rotation) { _, new in camera.rotation = new }
    }

    private func hueRow(_ title: String, value: Binding<Double?>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.subheadline.weight(.semibold))
            HStack(spacing: 6) {
                ForEach(hues) { choice in
                    Button(choice.id) { value.wrappedValue = choice.hue }
                        .font(.caption.weight(.bold))
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Capsule().fill(value.wrappedValue == choice.hue ? Theme.disc : Color.clear))
                        .foregroundStyle(value.wrappedValue == choice.hue ? Theme.field : Theme.chalk)
                        .overlay(Capsule().stroke(Theme.edge, lineWidth: 1))
                }
            }
        }
    }
}

struct HistoryView: View {
    @EnvironmentObject var store: GameStore

    var body: some View {
        List {
            if store.plays.isEmpty {
                Text("No plays yet. Every call lands here with its confidence and the evidence behind it.")
                    .foregroundStyle(Theme.muted)
            }
            ForEach(store.plays.reversed()) { play in
                VStack(alignment: .leading, spacing: 4) {
                    Text(play.banner).font(.subheadline.weight(.semibold))
                    Text("\(Int(play.confidence * 100))% · \(play.applied ? "applied" : "not applied")")
                        .font(.caption.monospaced()).foregroundStyle(Theme.muted)
                    ForEach(play.reasons, id: \.self) { reason in
                        Text(reason).font(.caption).foregroundStyle(Theme.muted)
                    }
                }
                .padding(.vertical, 4)
            }
        }
        .navigationTitle("History")
    }
}
