import AVFoundation
import CoreImage
import SwiftUI
import UIKit

/// Owns the capture session and the whole per-frame path:
/// frame -> glow blobs -> court estimate -> classified detections -> tracker ->
/// state machine.
///
/// Detection runs on the capture queue, never on the main thread — a 720p frame
/// scan plus flood fill is cheap, but doing it on the UI thread would still cost
/// you preview smoothness. Only the small published summary hops to main.
final class CameraController: NSObject, ObservableObject {
    @Published var authorized = false
    @Published var running = false
    @Published var status: StatusBadge = .watching
    @Published var notice: String?
    @Published var tracks: [Track] = []
    @Published var blobCount = 0
    @Published var analysisFPS = 0.0

    /// Court state, surfaced only as a one-line readout. There is nothing to
    /// confirm and nothing to tap — this is the app telling you what it worked
    /// out, not asking you to check it.
    @Published var courtReady = false
    @Published var courtConfidence = 0.0
    @Published var courtSummary = "Looking for the court"
    @Published var colorSummary = "learning colours"
    @Published var cloudSummary = "Cloud review idle"

    /// Pinch-to-zoom, exactly like the camera app: 1× is the wide lens and the
    /// ceiling is whatever the device can actually do. This exists so the phone
    /// can sit at a comfortable distance instead of being shoved back until both
    /// poles happen to fit in frame.
    @Published var zoom: CGFloat = 1
    @Published private(set) var minZoom: CGFloat = 1
    @Published private(set) var maxZoom: CGFloat = 1

    let session = AVCaptureSession()

    /// Touched only from `queue` once capture starts.
    let classifier = GlowClassifier()
    let machine = PlayStateMachine()
    private let tracker = Tracker()
    private let courtDetector = CourtDetector()
    private var detector = GlowDetector()

    /// Actor, safe to call from anywhere.
    let vision = CloudVision()

    /// Set by the preview so the rotation coordinator can level to it.
    weak var previewLayer: AVCaptureVideoPreviewLayer?

    /// A resolved play, with the keyframes that cover it.
    var onOutcome: ((PlayOutcome, [Data]) -> Void)?

    private let queue = DispatchQueue(label: "polescore.camera", qos: .userInitiated)
    private var configured = false
    private var lastAnalysis: Double = 0
    private var fpsWindow: [Double] = []
    private var device: AVCaptureDevice?
    private var rotationCoordinator: AVCaptureDevice.RotationCoordinator?
    private var rotationObservations: [NSKeyValueObservation] = []
    private var zoomAtGestureStart: CGFloat = 1

    // Keyframes for cloud review. Small, JPEG, in memory, never written to disk
    // and never uploaded unless a play actually resolves.
    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])
    private var keyframes: [(t: Double, data: Data)] = []
    private var lastKeyframeAt: Double = 0
    private let keyframeInterval: Double = 0.4
    private let keyframeWindow: Double = 4.5

    // Cloud court reads: one when the scene first settles, and again only if
    // the scene changes underneath us.
    private var courtRequestInFlight = false
    private var lastCourtRequestAt: Double = 0
    private var cloudCourtAccepted = false
    private var lastCloudStatusAt: Double = 0
    private var restedTrackIds = Set<Int>()
    private var watchingSince: Double = 0

    // Last values actually pushed to the UI. The court estimate is recomputed
    // every frame and drifts by fractions of a percent as anchors settle;
    // republishing that at frame rate would redraw the whole game screen 24
    // times a second to change nothing anybody can see.
    private var publishedCourtReady = false
    private var publishedCourtSummary = ""
    private var publishedCourtConfidence = 0.0

    // Written on main, read on the capture queue. Guarded by a lock because a
    // torn read of the court mid-frame would put the ground line in the wrong
    // place for exactly one decision — which is the decision that matters.
    private let lock = NSLock()
    private var _court: Court?
    private var _scoringEnabled = true
    private var _frameInterval: Double = 1.0 / 24.0

    var court: Court? {
        get { lock.lock(); defer { lock.unlock() }; return _court }
        set { lock.lock(); _court = newValue; lock.unlock() }
    }

    var scoringEnabled: Bool {
        get { lock.lock(); defer { lock.unlock() }; return _scoringEnabled }
        set { lock.lock(); _scoringEnabled = newValue; lock.unlock() }
    }

    func setAnalysisFPS(_ fps: Double) {
        lock.lock(); _frameInterval = 1.0 / max(4, fps); lock.unlock()
    }

    // MARK: - Session

    /// iOS terminates the process — no catchable error — if you touch the
    /// camera APIs without a usage description in place. So check first and
    /// report it rather than dying on launch.
    static var hasCameraUsageDescription: Bool {
        Bundle.main.object(forInfoDictionaryKey: "NSCameraUsageDescription") != nil
    }

    @MainActor
    func requestAccess() async {
        guard Self.hasCameraUsageDescription else {
            authorized = false
            notice = "Camera capability is missing. In Swift Playgrounds open App Settings, "
                + "add the Camera capability with a description, then run again."
            return
        }

        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            authorized = true
        case .notDetermined:
            authorized = await AVCaptureDevice.requestAccess(for: .video)
        default:
            authorized = false
        }
        if authorized { configure() }
    }

    func configure() {
        guard !configured, Self.hasCameraUsageDescription else { return }
        configured = true

        session.beginConfiguration()
        session.sessionPreset = .hd1280x720

        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: camera),
              session.canAddInput(input) else {
            session.commitConfiguration()
            publish { self.notice = "No rear camera available." }
            return
        }
        session.addInput(input)
        device = camera

        let output = AVCaptureVideoDataOutput()
        output.videoSettings = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarFullRange
        ]
        output.alwaysDiscardsLateVideoFrames = true
        output.setSampleBufferDelegate(self, queue: queue)
        if session.canAddOutput(output) { session.addOutput(output) }

        session.commitConfiguration()

        // Zoom range comes from the hardware, not from a guess. The ceiling is
        // capped below the format maximum because past a point it is pure
        // upscaling and the detector gets nothing out of it.
        let low = camera.minAvailableVideoZoomFactor
        let high = min(camera.activeFormat.videoMaxZoomFactor, 12)
        let current = camera.videoZoomFactor
        publish {
            self.minZoom = low
            self.maxZoom = max(high, low)
            self.zoom = min(max(current, low), max(high, low))
        }

        // Continuous auto exposure helps in the dark. Longer exposures smear a
        // flying disc into a streak, which the threshold still finds — one more
        // reason brightness beats a model on a lit set.
        if (try? camera.lockForConfiguration()) != nil {
            if camera.isExposureModeSupported(.continuousAutoExposure) {
                camera.exposureMode = .continuousAutoExposure
            }
            if camera.isFocusModeSupported(.continuousAutoFocus) {
                camera.focusMode = .continuousAutoFocus
            }
            camera.unlockForConfiguration()
        }

        startRotationTracking()
    }

    func start() {
        guard authorized, Self.hasCameraUsageDescription else { return }
        configure()
        queue.async { [session] in
            if !session.isRunning { session.startRunning() }
        }
        publish { self.running = true }
    }

    func stop() {
        queue.async { [session] in
            if session.isRunning { session.stopRunning() }
        }
        publish { self.running = false }
    }

    func resetTracking() {
        queue.async {
            self.tracker.reset()
            self.machine.reset()
            self.classifier.reset()
            self.keyframes.removeAll()
        }
    }

    /// Start over on the court — used when the phone is moved or zoomed. The
    /// learned colours survive, because the set on the field did not change.
    func rediscoverCourt() {
        court = nil
        // Everything below is capture-queue state. Reaching in from main would
        // be a race against the frame currently being analysed, so the whole
        // reset is handed to the queue that owns it.
        queue.async {
            self.courtDetector.reset()
            self.tracker.reset()
            self.machine.reset()
            self.cloudCourtAccepted = false
            self.lastCourtRequestAt = 0
            self.restedTrackIds.removeAll()
            self.watchingSince = 0
            self.publishCourtState(ready: false, confidence: 0,
                                   summary: "Looking for the court")
        }
    }

    // MARK: - Rotation

    /// Orientation used to be a four-way picker in Settings, on the theory that
    /// the sensor's idea of "up" varies by device. It does — which is exactly
    /// why the system will tell you, if you ask. This asks.
    private func startRotationTracking() {
        guard let device else { return }
        let coordinator = AVCaptureDevice.RotationCoordinator(device: device, previewLayer: previewLayer)
        rotationCoordinator = coordinator
        rotationObservations = [
            coordinator.observe(\.videoRotationAngleForHorizonLevelPreview,
                                options: [.initial, .new]) { [weak self] coordinator, _ in
                let angle = coordinator.videoRotationAngleForHorizonLevelPreview
                DispatchQueue.main.async { self?.applyPreviewRotation(angle) }
            },
            coordinator.observe(\.videoRotationAngleForHorizonLevelCapture,
                                options: [.initial, .new]) { [weak self] coordinator, _ in
                let angle = coordinator.videoRotationAngleForHorizonLevelCapture
                DispatchQueue.main.async { self?.applyCaptureRotation(angle) }
            }
        ]
    }

    private func applyPreviewRotation(_ angle: CGFloat) {
        guard let connection = previewLayer?.connection,
              connection.isVideoRotationAngleSupported(angle) else { return }
        connection.videoRotationAngle = angle
    }

    /// Applied to the analysis buffer as well as the preview, so the debug
    /// overlay and the detector never disagree with what you see.
    private func applyCaptureRotation(_ angle: CGFloat) {
        for output in session.outputs {
            for connection in output.connections where connection.isVideoRotationAngleSupported(angle) {
                connection.videoRotationAngle = angle
            }
        }
    }

    func attachPreview(_ layer: AVCaptureVideoPreviewLayer) {
        previewLayer = layer
        rotationObservations = []
        rotationCoordinator = nil
        startRotationTracking()
    }

    // MARK: - Zoom

    private func clampZoom(_ value: CGFloat) -> CGFloat {
        min(max(value, minZoom), max(minZoom, maxZoom))
    }

    /// Pinch begins: remember where we were, so the gesture scales from there
    /// rather than jumping.
    func beginZoomGesture() {
        zoomAtGestureStart = zoom
    }

    func updateZoomGesture(scale: CGFloat) {
        setZoom(zoomAtGestureStart * scale)
    }

    func setZoom(_ factor: CGFloat, animated: Bool = false) {
        guard let device else { return }
        let target = clampZoom(factor)
        guard (try? device.lockForConfiguration()) != nil else { return }
        if animated {
            device.ramp(toVideoZoomFactor: target, withRate: 6)
        } else {
            device.cancelVideoZoomRamp()
            device.videoZoomFactor = target
        }
        device.unlockForConfiguration()

        // Zooming changes every normalized coordinate in the frame, so the court
        // measured before the pinch is no longer the court. Rather than rescale
        // it and be subtly wrong about the ground line — the one measurement
        // worth a point per play — read it again.
        let changed = abs(target - zoom) > 0.01
        zoom = target
        if changed { rediscoverCourt() }
    }

    /// Double-tap: snap between 1× and 2×, the way the camera app does.
    func toggleZoom() {
        setZoom(zoom > 1.5 ? 1 : min(2, maxZoom), animated: true)
    }

    // MARK: - Helpers

    private func publish(_ block: @escaping () -> Void) {
        if Thread.isMainThread {
            block()
        } else {
            DispatchQueue.main.async(execute: block)
        }
    }

    /// Publish court state only when it changed enough to be worth a redraw.
    private func publishCourtState(ready: Bool, confidence: Double, summary: String) {
        guard ready != publishedCourtReady
            || summary != publishedCourtSummary
            || abs(confidence - publishedCourtConfidence) > 0.02 else { return }
        publishedCourtReady = ready
        publishedCourtSummary = summary
        publishedCourtConfidence = confidence
        publish {
            self.courtReady = ready
            self.courtConfidence = confidence
            self.courtSummary = summary
        }
    }

    /// Downscaled JPEG of the current frame. Small on purpose: the model needs
    /// to see where things are, not read the label on the bottle.
    private func encode(_ pixelBuffer: CVPixelBuffer) -> Data? {
        let image = CIImage(cvPixelBuffer: pixelBuffer)
        let width = image.extent.width
        guard width > 1 else { return nil }
        let scale = min(1, 640 / width)
        let scaled = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        guard let cgImage = ciContext.createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cgImage).jpegData(compressionQuality: 0.55)
    }
}

extension CameraController: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let timestamp = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sampleBuffer))

        lock.lock()
        let interval = _frameInterval
        let knownCourt = _court
        let scoring = _scoringEnabled
        lock.unlock()

        guard timestamp - lastAnalysis >= interval else { return }
        let previous = lastAnalysis
        lastAnalysis = timestamp

        let blobs = detector.detect(pixelBuffer)

        // --- court ----------------------------------------------------------
        courtDetector.observe(blobs: blobs, timestamp: timestamp)
        if knownCourt != nil, courtDetector.hasDrifted() {
            // The set moved, or the phone did. Whatever we were scoring against
            // is stale; drop it rather than keep measuring against a fiction.
            courtDetector.reset()
            machine.reset()
            tracker.reset()
            restedTrackIds.removeAll()
            watchingSince = 0
            self.court = nil
            cloudCourtAccepted = false
            publishCourtState(ready: false, confidence: 0,
                              summary: "Scene changed — reading the court again")
            return
        }

        if let estimate = courtDetector.current {
            watchingSince = 0
            self.court = estimate.court
            publishCourtState(ready: true,
                              confidence: estimate.confidence,
                              summary: estimate.source.label)
            requestCloudCourtIfUseful(pixelBuffer, timestamp: timestamp,
                                      litCount: blobs.count, estimate: estimate)
        } else {
            if watchingSince == 0 { watchingSince = timestamp }
            let progress = courtDetector.progress
            publishCourtState(ready: false, confidence: 0,
                              summary: progress > 0.05
                                  ? "Reading the court… \(Int(progress * 100))%"
                                  : "Looking for the court")
            // The local detector needs the poles or the bottles to be lit and
            // still. When they are not — unlit poles, a busy background, a set
            // that has faded — it finds nothing at all, and that is precisely
            // the case a model handles and geometry cannot. So ask, rather than
            // sit at "Looking for the court" indefinitely.
            requestCloudCourtIfUseful(pixelBuffer, timestamp: timestamp,
                                      litCount: blobs.count, estimate: nil)
        }

        // --- detection ------------------------------------------------------
        let activeCourt = self.court
        let detections = classifier.classify(blobs: blobs, court: activeCourt)
        let currentTracks = tracker.update(detections, timestamp: timestamp)

        // Anything that was thrown and has now stopped is a ground-line sample.
        // Over a couple of plays this is a better ground line than any guess,
        // because it is literally the height at which things stop falling.
        // Once per track, not once per frame: a disc that lies still for ten
        // seconds is one observation of the ground, not two hundred and forty
        // of them, and letting it vote that often would drown out every other
        // landing spot on the field.
        for track in currentTracks where track.label == .disc {
            if !restedTrackIds.contains(track.id),
               track.hits >= 8,
               track.meanSpeed(window: 0.4) <= 0.03,
               let first = track.history.first?.c,
               distance(first, track.box.center) >= 0.18 {
                restedTrackIds.insert(track.id)
                courtDetector.observeRest(track.box.center)
            }
        }
        if restedTrackIds.count > 200 { restedTrackIds.removeAll() }

        // --- keyframes ------------------------------------------------------
        if activeCourt != nil, timestamp - lastKeyframeAt >= keyframeInterval {
            lastKeyframeAt = timestamp
            if let data = encode(pixelBuffer) {
                keyframes.append((t: timestamp, data: data))
            }
            keyframes.removeAll { timestamp - $0.t > keyframeWindow }
        }

        // The cloud status line has to stay honest whether the last call was a
        // court read or a play review, and play reviews are issued by the store
        // rather than from here — so poll the actor rather than try to catch
        // every path that might have changed it.
        if timestamp - lastCloudStatusAt > 10 {
            lastCloudStatusAt = timestamp
            Task { [weak self] in
                guard let self else { return }
                let status = await self.vision.snapshot()
                self.publish {
                    self.cloudSummary = status.available
                        ? (status.made == 0
                           ? "Cloud review ready"
                           : "Cloud review on · \(status.succeeded)/\(status.made) calls")
                        : "Cloud review unavailable — scoring on device"
                }
            }
        }

        // On a glow set a dark frame is the *good* case, so quality is about
        // whether anything is lit at all, not about exposure.
        let quality = blobs.isEmpty ? 0.35 : 0.95

        // Tracking still runs above (so the preview overlay always shows what's
        // actually lit) but the state machine only sees frames once there is a
        // real court to measure against. Otherwise it just watches.
        let result: MachineOutput
        if let activeCourt {
            result = machine.update(tracks: currentTracks, court: activeCourt,
                                    timestamp: timestamp, quality: quality)
        } else {
            machine.reset()
            result = MachineOutput(state: .idle, status: .watching, outcome: nil, notice: nil)
        }

        var fps = 0.0
        if previous > 0 {
            let delta = timestamp - previous
            if delta > 0 {
                fpsWindow.append(1 / delta)
                if fpsWindow.count > 30 { fpsWindow.removeFirst() }
                fps = fpsWindow.reduce(0, +) / Double(fpsWindow.count)
            }
        }

        let snapshot = currentTracks
        let blobTotal = blobs.count
        let outcome = result.outcome
        let frames = outcome == nil ? [] : recentKeyframes()
        let colors = classifier.colors.summary

        DispatchQueue.main.async {
            self.tracks = snapshot
            self.blobCount = blobTotal
            self.status = result.status
            self.notice = result.notice
            self.colorSummary = colors
            if fps > 0 { self.analysisFPS = fps }
            if let outcome, scoring { self.onOutcome?(outcome, frames) }
        }
    }

    /// The handful of frames a model actually needs: start, middle, end. More
    /// than that costs tokens and adds nothing — the play is four seconds long.
    private func recentKeyframes() -> [Data] {
        guard !keyframes.isEmpty else { return [] }
        let all = keyframes.map(\.data)
        guard all.count > 3 else { return all }
        return [all[0], all[all.count / 2], all[all.count - 1]]
    }

    /// Ask the cloud model to read the court once the scene has settled, and
    /// only while the local answer is still a guess. A confident local read from
    /// lit poles needs no second opinion, and a second opinion costs a request
    /// out of a free-tier minute.
    private func requestCloudCourtIfUseful(_ pixelBuffer: CVPixelBuffer, timestamp: Double,
                                           litCount: Int, estimate: CourtEstimate?) {
        guard !cloudCourtAccepted, !courtRequestInFlight else { return }
        // A confident local read — lit poles, measured rather than guessed —
        // needs no second opinion, and a second opinion costs a request out of
        // a free-tier minute.
        if let estimate, estimate.confidence >= 0.8 { return }
        // With nothing lit in shot there is nothing for a model to find either.
        guard litCount >= 2 else { return }
        // When there is no local estimate at all, give the scene a few seconds
        // to settle first — otherwise the phone being carried to the court
        // burns the request on a picture of somebody's knees.
        if estimate == nil {
            guard watchingSince > 0, timestamp - watchingSince > 6 else { return }
        }
        guard timestamp - lastCourtRequestAt > 30 else { return }
        guard let jpeg = encode(pixelBuffer) else { return }

        lastCourtRequestAt = timestamp
        courtRequestInFlight = true

        Task { [weak self] in
            guard let self else { return }
            let result = await self.vision.detectCourt(jpeg: jpeg, litCount: litCount)
            let status = await self.vision.snapshot()
            self.queue.async {
                self.courtRequestInFlight = false
                if let result {
                    self.courtDetector.accept(result)
                    self.cloudCourtAccepted = true
                    if let refined = self.courtDetector.current {
                        self.court = refined.court
                        self.publish {
                            self.courtReady = true
                            self.courtConfidence = refined.confidence
                            self.courtSummary = refined.source.label
                        }
                    }
                }
                self.publish {
                    self.cloudSummary = status.available
                        ? "Cloud review on · \(status.succeeded)/\(status.made) calls"
                        : "Cloud review unavailable — scoring on device"
                }
            }
        }
    }
}

/// Live preview. Stores its layer on the controller so rotation can level to it.
struct CameraPreview: UIViewRepresentable {
    let controller: CameraController

    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.videoPreviewLayer.session = controller.session
        view.videoPreviewLayer.videoGravity = .resizeAspectFill
        controller.attachPreview(view.videoPreviewLayer)
        return view
    }

    func updateUIView(_ uiView: PreviewView, context: Context) {}

    final class PreviewView: UIView {
        override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
        var videoPreviewLayer: AVCaptureVideoPreviewLayer {
            layer as! AVCaptureVideoPreviewLayer
        }
    }
}
