import Foundation

/// The cloud half of detection and scoring.
///
/// The on-device path is the primary one: brightness blobs, tracking, and a
/// temporal state machine. It runs at frame rate, needs no network, and costs
/// nothing. This adds a vision model on top of it for the two jobs geometry
/// alone is worst at:
///
///   1. **Reading the court.** One frame, once, at the start: where are the
///      poles and where is the ground line? That is a perception problem, not a
///      measurement problem, and it is exactly what a model is for. It is also
///      what used to be six taps of setup.
///   2. **Adjudicating a play.** A handful of keyframes plus the numbers the
///      state machine measured, and one question: what actually happened?
///
/// Two rules shape everything here.
///
/// **It never blocks the game.** Every call is asynchronous with a short
/// timeout. If the network is dead, the request is slow, or no key is
/// configured on the server, the on-device call already stands and the reply is
/// ignored when it arrives. There is no spinner, no prompt, no pause.
///
/// **It is rate-limited on purpose.** The backend runs on a free tier with a
/// requests-per-minute cap. One call per play and one court read per scene sits
/// well inside it; a per-frame call would not. The limiter below is what keeps
/// that promise even when a game gets busy.
struct VisionCourt {
    var leftTop: Pt
    var rightTop: Pt
    var leftBase: Pt
    var rightBase: Pt
    var groundA: Pt
    var groundB: Pt
    var confidence: Double
}

struct VisionCall {
    var klass: PlayClass
    var confidence: Double
    var reason: String
}

actor CloudVision {

    /// Free-tier headroom. Well under the published per-minute cap, so a long
    /// game never trips it even with plays coming fast.
    private let minimumInterval: Double = 4.0
    private var lastCallAt: Date?

    /// After repeated failures — no key on the server, no network, a quota wall
    /// — stop asking for a while. A backend that is not there must cost the
    /// game nothing, including the latency of finding out.
    private var consecutiveFailures = 0
    private var mutedUntil: Date?

    private var lastError: String?
    private var callsMade = 0
    private var callsSucceeded = 0

    private var isAvailable: Bool {
        guard CloudDefaults.isConfigured else { return false }
        if let mutedUntil, mutedUntil > Date() { return false }
        return true
    }

    private func reserveSlot() -> Bool {
        guard isAvailable else { return false }
        if let last = lastCallAt, Date().timeIntervalSince(last) < minimumInterval { return false }
        lastCallAt = Date()
        return true
    }

    private func succeeded() {
        consecutiveFailures = 0
        mutedUntil = nil
        callsSucceeded += 1
        lastError = nil
    }

    private func failed(_ message: String) {
        consecutiveFailures += 1
        lastError = message
        // 30s, 60s, 120s ... capped at ten minutes.
        let backoff = min(600.0, 30.0 * pow(2.0, Double(consecutiveFailures - 1)))
        if consecutiveFailures >= 2 { mutedUntil = Date().addingTimeInterval(backoff) }
    }

    // MARK: - Wire format

    private struct CourtRequest: Encodable {
        var task = "court"
        var image: String
        var lit: Int
    }

    private struct CourtReply: Decodable {
        struct Point: Decodable { var x: Double; var y: Double }
        var found: Bool
        var left_top: Point?
        var right_top: Point?
        var left_base: Point?
        var right_base: Point?
        var confidence: Double?
        var note: String?
    }

    private struct PlayRequest: Encodable {
        var task = "play"
        var images: [String]
        var features: [Double]
        var rule_call: Int
        var rule_confidence: Double
    }

    private struct PlayReply: Decodable {
        var call: String
        var confidence: Double
        var reason: String?
    }

    private func post<Body: Encodable, Reply: Decodable>(
        _ body: Body, expecting: Reply.Type, timeout: Double
    ) async -> Reply? {
        guard let url = CloudDefaults.function("polescore") else { return nil }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        CloudDefaults.authorize(&request)
        request.timeoutInterval = timeout
        request.httpBody = try? JSONEncoder().encode(body)
        callsMade += 1
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                failed("No response.")
                return nil
            }
            // 404 means the function was never deployed; 401 and 429 mean it is
            // there but unusable right now. All three are "carry on without
            // it", which is what the backoff above arranges.
            guard (200...299).contains(http.statusCode) else {
                failed("HTTP \(http.statusCode)")
                return nil
            }
            guard let reply = try? JSONDecoder().decode(Reply.self, from: data) else {
                failed("Unreadable reply.")
                return nil
            }
            succeeded()
            return reply
        } catch {
            failed(error.localizedDescription)
            return nil
        }
    }

    // MARK: - Court

    /// Read the court out of a single frame. Returns nil for every failure —
    /// no network, no key, nothing recognisable in shot — and the local
    /// detector's answer stands.
    func detectCourt(jpeg: Data, litCount: Int) async -> VisionCourt? {
        guard reserveSlot() else { return nil }
        let body = CourtRequest(image: jpeg.base64EncodedString(), lit: litCount)
        guard let reply = await post(body, expecting: CourtReply.self, timeout: 25),
              reply.found,
              let lt = reply.left_top, let rt = reply.right_top,
              let lb = reply.left_base, let rb = reply.right_base else { return nil }

        // A model can invent a court in an empty field. These are the checks a
        // real court always passes: the poles are apart, the tops are above the
        // bases, and everything is inside the frame.
        let leftTop = Pt(x: clamp(lt.x, 0, 1), y: clamp(lt.y, 0, 1))
        let rightTop = Pt(x: clamp(rt.x, 0, 1), y: clamp(rt.y, 0, 1))
        let leftGround = Pt(x: clamp(lb.x, 0, 1), y: clamp(lb.y, 0, 1))
        let rightGround = Pt(x: clamp(rb.x, 0, 1), y: clamp(rb.y, 0, 1))

        guard abs(rightTop.x - leftTop.x) >= 0.12,
              leftGround.y - leftTop.y >= 0.04,
              rightGround.y - rightTop.y >= 0.04 else { return nil }

        // Left really means left, whatever the model chose to call them.
        let swapped = leftTop.x > rightTop.x
        let a = swapped ? rightTop : leftTop
        let aGround = swapped ? rightGround : leftGround
        let b = swapped ? leftTop : rightTop
        let bGround = swapped ? leftGround : rightGround

        return VisionCourt(leftTop: a, rightTop: b,
                           leftBase: aGround, rightBase: bGround,
                           groundA: aGround, groundB: bGround,
                           confidence: clamp(reply.confidence ?? 0.7, 0, 1))
    }

    // MARK: - Play

    /// Second opinion on a play that has already been scored. The score moved
    /// the moment the state machine decided; this either agrees, in which case
    /// nothing happens, or disagrees, in which case the caller corrects it
    /// inside the undo window.
    func judge(frames: [Data], features: PlayFeatures,
               ruleCall: PlayClass, ruleConfidence: Double) async -> VisionCall? {
        guard !frames.isEmpty, reserveSlot() else { return nil }
        let body = PlayRequest(images: frames.map { $0.base64EncodedString() },
                               features: features.vector,
                               rule_call: ruleCall.rawValue,
                               rule_confidence: ruleConfidence)
        guard let reply = await post(body, expecting: PlayReply.self, timeout: 20),
              let klass = PlayClass(wireName: reply.call) else { return nil }
        return VisionCall(klass: klass,
                          confidence: clamp(reply.confidence, 0, 1),
                          reason: reply.reason ?? "Cloud review.")
    }

    func snapshot() -> CloudVisionStatus {
        CloudVisionStatus(available: isAvailable,
                          made: callsMade,
                          succeeded: callsSucceeded,
                          error: lastError)
    }
}

struct CloudVisionStatus {
    var available = false
    var made = 0
    var succeeded = 0
    var error: String?
}
