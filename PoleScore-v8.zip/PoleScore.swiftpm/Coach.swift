import Foundation

/// In-app assistant.
///
/// Deliberately not a chatbot. There is a language model in this app now, but
/// it is pointed at the camera, not at the user — it looks at frames and says
/// what happened, which is a question it can actually answer. Asking it to
/// speculate about a court it cannot see would be worse than useless. So this
/// still reads what the app measured — live blob counts, the court estimate,
/// the calls it made, where you disagreed — and gives specific, checkable
/// advice. Every suggestion below is tied to a number the app can see.
struct CoachNote: Identifiable {
    enum Level { case good, warn, bad }
    var id = UUID()
    var level: Level
    var title: String
    var detail: String
}

enum Coach {

    /// Plain snapshot of the learning state. Taking a copy on the main actor and
    /// passing values keeps this function free of any actor isolation.
    struct LearningSnapshot {
        var examples: Int
        var poolSize: Int
        var modelAccuracy: Double
        var ruleAgreement: Double
        var groundVsCaughtConfusions: Int
        var sharingConfigured: Bool
    }

    struct SceneSnapshot {
        var blobCount: Int
        var fps: Double
        var courtReady: Bool
        var courtConfidence: Double
        var courtSummary: String
        var colorSummary: String
        var cloudSummary: String
    }

    static func diagnose(scene: SceneSnapshot,
                         mode: ScoringMode,
                         plays: [PlayRecord],
                         learning: LearningSnapshot) -> [CoachNote] {
        var notes: [CoachNote] = []

        // --- the court ------------------------------------------------------
        if !scene.courtReady {
            notes.append(CoachNote(level: .warn, title: "Still reading the court",
                                   detail: "Both poles need to be in shot and lit. It works this out by "
                                         + "watching which bright things stay put, so give it a few "
                                         + "seconds of a still frame — and keep the phone steady."))
        } else if scene.courtConfidence < 0.65 {
            notes.append(CoachNote(level: .warn, title: "Court found, but the ground line is a guess",
                                   detail: "It has the poles but nothing has told it where the grass is yet. "
                                         + "That resolves itself after a couple of throws — whatever "
                                         + "lands and stays put defines the floor. Until then, caught "
                                         + "and grounded bottles may be confused."))
        } else {
            notes.append(CoachNote(level: .good, title: "Court set — \(scene.courtSummary)",
                                   detail: "Confidence \(Int(scene.courtConfidence * 100))%. It re-reads "
                                         + "itself if the phone is bumped or you zoom."))
        }

        // --- what the camera sees -------------------------------------------
        switch scene.blobCount {
        case 0:
            notes.append(CoachNote(level: .bad, title: "Nothing lit is visible",
                                   detail: "Check the set is actually glowing and in frame. The brightness "
                                         + "cut-off adapts on its own, so there is nothing to turn down — "
                                         + "if it sees nothing, there is nothing bright enough to see."))
        case 1...2:
            notes.append(CoachNote(level: .warn, title: "Only \(scene.blobCount) lit object found",
                                   detail: "Expect at least 3 — two bottles and a disc. Move back, or pinch "
                                         + "to zoom out, until both poles are in frame."))
        case 3...8:
            notes.append(CoachNote(level: .good, title: "\(scene.blobCount) lit objects tracked",
                                   detail: "That is the right range for a two-pole court. Colours: \(scene.colorSummary)."))
        default:
            notes.append(CoachNote(level: .warn, title: "\(scene.blobCount) lit objects — too many",
                                   detail: "Stray lights are being picked up. Get porch lights and phone "
                                         + "screens out of frame; zooming in on the court also helps."))
        }

        if scene.fps > 0 && scene.fps < 12 {
            notes.append(CoachNote(level: .warn, title: "Analysing at only \(Int(scene.fps)) fps",
                                   detail: "Low light makes the camera itself slow down. Fast throws may be "
                                         + "missed between frames."))
        }

        notes.append(CoachNote(level: scene.cloudSummary.contains("unavailable") ? .warn : .good,
                               title: scene.cloudSummary,
                               detail: scene.cloudSummary.contains("unavailable")
                               ? "Everything still works — detection and scoring run on the device. The "
                                 + "cloud model only adds a second opinion on plays and a better first "
                                 + "read of the court."
                               : "A vision model reviews each play after it is scored, and corrects the "
                                 + "call if it disagrees. In Automatic mode that happens silently, inside "
                                 + "the undo window."))

        // --- what the calls look like ---------------------------------------
        let recent = plays.suffix(20)
        if recent.count >= 5 {
            let dead = recent.filter { $0.events.contains(.deadThrow) }.count
            if Double(dead) / Double(recent.count) > 0.4 {
                notes.append(CoachNote(level: .warn, title: "Many plays resolving as dead throws",
                                       detail: "Usually the disc is not being tracked. If the disc and the "
                                             + "bottles glow the same colour there is nothing to tell them "
                                             + "apart but position — a differently coloured disc is the "
                                             + "single biggest accuracy win available."))
            }
            let revised = recent.filter(\.revised).count
            if revised >= 3 {
                notes.append(CoachNote(level: .warn, title: "The cloud is overruling \(revised) of the last \(recent.count) calls",
                                       detail: "The on-device rules are systematically off. Coach → Tune "
                                             + "thresholds will pull them back toward the calls that are "
                                             + "actually being made."))
            }
        }

        // --- learning --------------------------------------------------------
        if learning.examples == 0 {
            notes.append(CoachNote(level: .warn, title: "It has not learned anything yet",
                                   detail: "In Automatic mode the cloud review supplies the labels, so this "
                                         + "fills up on its own as you play. In Ask-first mode every "
                                         + "confirmation or correction becomes an example."))
        } else if learning.examples < 8 {
            notes.append(CoachNote(level: .warn, title: "\(learning.examples) examples so far",
                                   detail: "Needs about 8 before the model starts influencing calls, and "
                                         + "around 40 before it carries real weight."))
        } else {
            let rules = Int(learning.ruleAgreement * 100)
            let model = Int(learning.modelAccuracy * 100)
            notes.append(CoachNote(level: model >= rules ? .good : .warn,
                                   title: "Learned model: \(model)% vs rules \(rules)%",
                                   detail: model >= rules
                                   ? "The model now matches the confirmed calls at least as well as the "
                                     + "fixed rules, and is being blended in."
                                   : "The fixed rules still agree more often. Keep playing — or run Tune "
                                     + "thresholds, which often helps faster than the model."))
        }

        // --- the mode you are in ---------------------------------------------
        switch mode {
        case .auto where learning.examples < 15 && !learning.sharingConfigured:
            notes.append(CoachNote(level: .warn, title: "Automatic mode with little history",
                                   detail: "It will score on its own before it has learned this court, and "
                                         + "with no cloud review reachable there is nothing checking it. "
                                         + "Ask-first for a game is the safer trade."))
        case .auto:
            notes.append(CoachNote(level: .good, title: "Automatic mode",
                                   detail: "Nothing will interrupt you. Calls apply on their own and the "
                                         + "cloud review corrects them silently while undo is still open."))
        case .assist:
            notes.append(CoachNote(level: .good, title: "Ask-first mode",
                                   detail: "Every call waits for a tap, and every tap is a training example. "
                                         + "This is the fastest way to teach it your court."))
        case .manual:
            notes.append(CoachNote(level: .warn, title: "Tap-only mode",
                                   detail: "The camera is running for the overlay but is not scoring. Switch "
                                         + "to Automatic or Ask-first to use any of it."))
        }

        // --- the disagreements that matter ------------------------------------
        if learning.groundVsCaughtConfusions >= 3 {
            notes.append(CoachNote(level: .bad, title: "Confusing caught bottles with grounded ones",
                                   detail: "That is almost always the ground line sitting too high. It "
                                         + "corrects itself as more throws land, but tapping Re-read the "
                                         + "court with the poles clearly in shot fixes it faster — it is "
                                         + "the measurement worth exactly one point per play."))
        }

        return notes
    }

    /// Plain-language explanation of a single call, from the evidence recorded
    /// at the time — not a guess after the fact.
    static func explain(_ play: PlayRecord) -> String {
        var lines = ["Called: \(play.banner)", "Confidence: \(Int(play.confidence * 100))%"]
        lines.append(contentsOf: play.reasons.map { "· \($0)" })
        if play.revised {
            lines.append("This call was revised by the cloud review.")
        }
        if !play.applied {
            lines.append("This one did not change the score.")
        }
        return lines.joined(separator: "\n")
    }

    struct Question: Identifiable {
        var id: String { question }
        let question: String
        let answer: String
    }

    static let questions: [Question] = [
        Question(question: "Do I have to set the court up?",
                 answer: "No. It watches for the two bright things that stay in one place — the bottles on "
                       + "the pole tops — and takes the ground line from the lit poles, or from wherever "
                       + "thrown objects come to rest. If the cloud model is reachable it reads the whole "
                       + "court from one frame instead. Move the phone or zoom and it starts over by itself."),
        Question(question: "What is the difference between the modes?",
                 answer: "Automatic never interrupts you: it calls every play, scores it, and if the cloud "
                       + "review disagrees it silently corrects the call inside the undo window. Ask-first "
                       + "waits for a tap on every play and turns your answer into training data. Tap-only "
                       + "ignores the camera for scoring and gives you buttons."),
        Question(question: "Why did it score 2 instead of 3?",
                 answer: "It decided the bottle was caught rather than grounded. A catch means the bottle "
                       + "stopped moving above the detected ground line. If that keeps being wrong the "
                       + "ground line is too high — Re-read the court, or play a few more throws so it can "
                       + "learn the floor from where things land."),
        Question(question: "Can I zoom in?",
                 answer: "Pinch anywhere on the game screen, exactly like the camera app; double-tap snaps "
                       + "between 1× and 2×. Zooming changes every measurement in the frame, so the court "
                       + "is re-read automatically straight afterwards."),
        Question(question: "Does any of this cost money?",
                 answer: "No. Detection and scoring run on the device. The shared-learning pool and the "
                       + "cloud review both run on free tiers, and the cloud review is called once per "
                       + "play rather than per frame specifically to stay inside them. If the quota is "
                       + "gone or the network is down, the app backs off and scores on device."),
        Question(question: "It missed the throw entirely.",
                 answer: "A play can start two ways: the disc being tracked at speed, or a bottle leaving a "
                       + "pole top. If neither registered, the disc is probably not being detected — check "
                       + "the lit count on the game screen while holding the disc up.")
    ]
}
