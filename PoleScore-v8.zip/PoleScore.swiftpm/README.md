# PoleScore for Swift Playgrounds

Live camera scoring for a glow-in-the-dark Strike Pole / Beersbee set, built to
run on your iPad or iPhone straight from Swift Playgrounds — **no Apple
Developer account, no cloud build, no expiry to work around.**

## Getting it running

1. Download the zip on the device, then unzip it in the **Files** app (long
   press → Uncompress).
2. Tap `PoleScore.swiftpm`. It opens in Swift Playgrounds.
3. **Turn on camera access before the first run.** Tap the app-settings control
   in Playgrounds (the ⚙/app icon at the top), find **Capabilities**, add
   **Camera**, and give it a description like "Watches the court to score
   plays." Without this the app builds fine but the preview stays black.
4. Press ▶ to run. Playgrounds installs it to your home screen, where it runs
   like any other app.

If it ever stops launching from the home screen, open it in Playgrounds and run
it once more.

## At the court

1. Prop the device sideways so both poles are in frame.
2. **Pinch to zoom** until the court fills a comfortable amount of the frame.
   You do not have to walk backwards to fit the poles in any more.
3. **Start game.**

There is no setup step. The app works out where the court is by watching it —
see below — and tells you when it has it, on one line at the top of the game
screen. Nothing to tap, nothing to confirm.

## The three modes

| Mode | What it does |
|---|---|
| **Automatic** (default) | Hands off. Every play is called and scored on its own — no prompts, no pauses, nothing to confirm, and no waiting for anyone to press anything. A cloud review runs in the background and silently corrects a call it disagrees with, while the undo window is still open. |
| **Ask first** | Every call waits for one tap before the score moves. Costs a tap per play and gives the learning system a human label each time. |
| **Tap only** | A plain scoreboard with big buttons. Detection still runs for the overlay. Always available, works regardless of the camera. |

Automatic is the default and is genuinely uninterrupted: it will not ask you
about a low-confidence call, it will not stop to ask whether a bottle has been
put back on its pole, and it never shows a confirm or correction pad. Where the
other two modes ask you a question, Automatic asks the cloud model instead.

## The court reads itself

There used to be a six-tap setup: both pole tops, both bottles, and the ground
at each pole. It produced the single most important measurement in the app — the
ground line, which separates a caught bottle from one lying in the grass, worth
one point every time it is wrong — and it was also the thing most likely to be
rushed, skipped, or invalidated the moment somebody nudged the phone.

So it is inferred instead, from three things a beersbee court gives away for
free:

- **Bottles do not move.** Between throws, the two brightest things that stay in
  the same spot frame after frame are the bottles on the pole tops.
- **Poles are long and vertical.** When the set glows, a pole is a tall thin
  streak whose lower end is the ground line, read directly rather than guessed.
- **Things that fall come to rest on the ground.** When the poles are not lit,
  the ground line is learned from where thrown objects stop and stay. A couple
  of plays is enough.

On top of that, if the cloud model is reachable it is shown one frame and asked
to read the whole court at once — which is a perception problem, and exactly
what a model is for. Its answer replaces the local one when it is confident.

Everything above re-runs by itself if the scene changes: bump the phone, move
the set, or pinch to zoom, and the court is read again from scratch. Zoom
specifically invalidates it, because zooming moves every normalized coordinate
in the frame.

## Colours read themselves too

Settings used to have three colour pickers — disc, bottles, poles. That was the
wrong shape for the problem twice over: it asked you to configure something you
would only discover was wrong mid-game, and it stored a *constant* for a
quantity that drifts all evening as glow fades toward green, or changes outright
when somebody brings out a different disc.

Now every object the app identifies confidently by position and motion becomes a
colour sample. Hue is averaged as an angle (the mean of 350° and 10° is 0°, not
180°), and the *length* of that average measures how consistent the samples were.
Colour matching only switches on when the disc and the bottles are demonstrably
different colours; on a single-colour set the app keeps using position and
motion, which is the right answer rather than a degraded one.

The brightness threshold is chosen the same way — from each frame's own
histogram, so that roughly the right *share* of the frame comes back lit. A set
at full charge and the same set two hours later both land in range with nothing
to adjust. Camera orientation comes from the system's rotation coordinator, so
that picker is gone as well.

## Catch vs ground

This is what your rules hinge on. In the dark there are no visible players, so a
catch is recognised by **height**: an object that stops moving well above the
detected ground line is being held; one that stops at the line is not.

| What happened | How it is recognised |
|---|---|
| Disc caught | Disc was moving, then stops **above** the ground line |
| Disc hits the ground | Disc reaches the ground line and settles |
| Bottle knocked, then caught | Bottle leaves the pole top, then stops **above** the line |
| Bottle knocked, hits ground | Bottle leaves the pole top and reaches the line |

One subtlety that caused a real bug during development: the first moments of a
bottle toppling look *exactly* like a catch — high up and barely moving. So a
catch requires motion **followed by** stillness. An object that never moved fast
during a play can never be called caught.

## The cloud model

Two jobs, both of which geometry alone is bad at:

1. **Reading the court** from one frame, once, when the local estimate is still
   a guess.
2. **Adjudicating a play** — three keyframes plus the numbers the state machine
   measured, and one question: what actually happened?

Two rules govern it. **It never blocks the game**: every call is asynchronous
with a short timeout, the on-device call has already been applied, and a reply
that arrives too late or never is simply ignored. **It is rate-limited on
purpose**: one call per play and one court read per scene, because it runs on a
free tier with a per-minute cap. After repeated failures it backs off
exponentially and stops asking, so a backend that is not there costs the game
nothing — not even the latency of finding out.

Everything works with no cloud model at all. Detection, tracking, scoring, and
the local court read are all on-device.

### Setting the cloud model up (optional, free)

1. Install the Supabase CLI and link the project (`ovtmvlqfafrwlyjhbsow`).
2. Get a free API key from Google AI Studio.
3. ```
   supabase secrets set GEMINI_API_KEY=your-key-here
   supabase functions deploy polescore
   ```

The function source is `supabase/functions/polescore/index.ts`. It picks its
provider from whichever secret is set: `GEMINI_API_KEY` (free tier — the
default) or `ANTHROPIC_API_KEY` (Claude; better, but billed per token, with no
free tier). With neither set it returns 503 and the app scores on device.

**The model key must live here, not in the app.** The Supabase anon key is safe
to ship in client code because row-level security bounds what it can do to
"insert one row of fourteen numbers". A model provider key has no equivalent
bound — anyone who extracts it can spend your quota on anything at all.

## How it gets better

**1. The cloud review is the labeller.** In Automatic mode, every play the cloud
reviews becomes a labelled training example whether it agreed or disagreed. That
is what lets Automatic mode keep learning without ever asking anyone a question.
In Ask-first mode your taps do the same job.

**2. Threshold tuning (evolutionary).** Coach → **Tune thresholds** runs a
mutation-and-selection loop over the six numbers that decide a call: catch
height, settle gate, bottle displacement, rest speed, pole proximity, confirm
frames. Fitness is how often a threshold set reproduces the calls that were
confirmed. Gradient descent is the wrong tool here — confirm frames is an
integer and the rules are hard comparisons with no derivative — but evolution
handles that fine and converges in under a second. **Needs about 8 examples.**

**3. A learned model.** A small neural network (14 inputs → 10 hidden → 6 calls)
trained by SGD on the same examples. Its opinion is blended into the confidence
score, weighted by how much evidence it has earned: at zero examples it has no
say at all, reaching meaningful weight around 40. It cannot make day one worse
than it already is.

## Learning across every install

Shared learning is always on. There is no switch, because a switch is something
that gets left in the wrong position on the one phone that had the best data.

**What actually leaves the device:** fourteen numbers per play and the correct
call. A row is literally `[1, 5, 0, 0.02, 0.41, ...] -> 0`. No video, no images,
no location, no account, no name. There is no path from a row back to a person.

Keyframes are sent to the cloud model only when a play resolves and only if a
model key is configured on the server. They are held in memory, never written to
disk, and never stored anywhere afterwards.

**Why it transfers between different courts:** every feature is normalized
against that install's own detected court. A bottle height of 0.02 means "just
above my ground line" whether the court is a backyard or a parking lot. Raw
pixels would be useless across users; calibrated ratios are directly comparable.

**Why more data is not automatically better — and how that is handled.** Other
people have different courts, different readings of the rules, and some will
have worse detection. So the app trains two models on every retrain: one on your
examples alone, one on yours plus the pool. Both are scored on *your* data, and
it keeps whichever predicts your calls better. Coach tells you which one won.

Run `supabase-schema.sql` in the SQL editor once and the table exists; the app
finds it with no setup on the device.

## Distributing it to other people

Worth knowing before you plan around it: **getting this app onto other people's
devices requires the $99/year Apple Developer Program**, through TestFlight or
the App Store. Swift Playgrounds can submit to the App Store, but the membership
is the gate. Nothing about shared learning changes that; it just means the pool
starts filling once other people actually have the app.

## Tuning

Watch the "lit" count on the game screen — it tells you how many bright regions
are being found right now.

| Symptom | Fix |
|---|---|
| Nothing detected | Check the set is glowing and in frame — the threshold adapts itself, so there is nothing to turn down |
| Stray lights detected | Pinch to zoom in on the court; keep porch lights out of frame |
| Court never found | Both poles must be in shot and lit; hold the phone still for a few seconds |
| Bottle and disc confused | Use a differently coloured disc — the app will learn the difference by itself |
| Score moves when it shouldn't | Switch to Ask first; check History for the evidence |
| Calls feel late | Normal — every event must hold for several frames before it counts |

## Honest limits

- Fading glow degrades detection. Recharge the set at halftime.
- A bottle landing behind a pole, hidden from the camera, cannot be resolved from
  geometry — this is exactly the case the cloud review exists to catch.
- Keep the device still. Low light means longer exposures and more motion blur,
  so a rigid mount matters more at night than in daylight. Moving the phone
  triggers a court re-read, which costs a few seconds of scoring.
- The free tier of the cloud model has a per-minute request cap. The app stays
  inside it by calling once per play; if you hit it anyway, it backs off and
  scores on device until the quota recovers.
- Nothing is uploaded except the fourteen numbers, and keyframes only when a
  cloud review actually runs. No video is recorded. Frames are analysed and
  dropped.
