import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var store: GameStore
    @EnvironmentObject var camera: CameraController
    @EnvironmentObject var learning: LearningStore

    var body: some View {
        Form {
            Section {
                Picker("Mode", selection: $store.mode) {
                    ForEach(ScoringMode.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                .pickerStyle(.segmented)
                Text(store.mode.detail).font(.footnote).foregroundStyle(Theme.muted)
            } header: {
                Text("How it keeps score")
            }

            Section {
                Picker("Rules", selection: Binding(
                    get: { store.rules.id },
                    set: { id in store.rules = RuleSet.presets.first { $0.id == id } ?? .beersbee }
                )) {
                    ForEach(RuleSet.presets) { Text($0.name).tag($0.id) }
                }
                Text(store.rules.detail).font(.footnote).foregroundStyle(Theme.muted)
            } header: {
                Text("Rules")
            }

            // Everything in this section used to be a control. It is a readout
            // now: the court, the glow colours, the brightness threshold and
            // the camera orientation are all worked out from what the camera
            // can see, and all four of them change during a game in ways a
            // saved setting could never keep up with.
            Section {
                LabeledContent("Court") {
                    Text(camera.courtReady ? camera.courtSummary : "Not read yet")
                        .foregroundStyle(camera.courtReady ? Theme.muted : Theme.flag)
                }
                LabeledContent("Confidence") {
                    Text("\(Int(camera.courtConfidence * 100))%").monospacedDigit().foregroundStyle(Theme.muted)
                }
                LabeledContent("Glow colours") {
                    Text(camera.colorSummary).foregroundStyle(Theme.muted)
                }
                LabeledContent("Zoom") {
                    Text(String(format: "%.1f×", camera.zoom)).monospacedDigit().foregroundStyle(Theme.muted)
                }
                LabeledContent("Cloud review") {
                    Text(camera.cloudSummary).foregroundStyle(Theme.muted)
                }
                Button("Re-read the court") { camera.rediscoverCourt() }
            } header: {
                Text("What it worked out")
            } footer: {
                Text("The poles, the ground line, the glow colours, the brightness cut-off and the "
                     + "camera orientation are all detected, continuously. Pinch the game screen to "
                     + "zoom — the court is re-read automatically afterwards, because zooming moves "
                     + "every measurement in the frame.")
            }

            Section {
                VStack(alignment: .leading) {
                    Text("Confidence to auto-score: \(Int(store.confidence * 100))%")
                    Slider(value: $store.confidence, in: 0.5...0.99)
                }
                Toggle("Developer overlay", isOn: $store.showDebug)
                Toggle("Use what it has learned", isOn: $learning.enabled)
            } header: {
                Text("Scoring")
            } footer: {
                Text("In Ask-first mode this decides which calls are flagged for review. In "
                     + "Automatic mode nothing is ever flagged to you — a call the app is unsure of "
                     + "is sent to the cloud model for a second opinion instead, and corrected "
                     + "quietly if it comes back different.")
            }

            Section {
                TextField("Team A", text: $store.teamAName)
                TextField("Team B", text: $store.teamBName)
            } header: {
                Text("Teams")
            }

            Section {
                LabeledContent("Examples from this device") {
                    Text("\(learning.count)").monospacedDigit().foregroundStyle(Theme.muted)
                }
                LabeledContent("From other players") {
                    Text("\(learning.pool.count)").monospacedDigit().foregroundStyle(Theme.muted)
                }
            } header: {
                Text("Shared learning")
            } footer: {
                Text("Always on, nothing to set up. Every install contributes anonymous play "
                     + "measurements and reads back the pool, so a new phone starts with everyone's "
                     + "experience instead of nothing. What leaves the device is fourteen numbers "
                     + "and the correct call — no video, no images, no identity.")
            }
        }
        .navigationTitle("Settings")
        .onChange(of: store.confidence) { _, new in camera.machine.config.confidenceThreshold = new }
        .onChange(of: store.mode) { _, new in
            camera.scoringEnabled = new != .manual
            camera.machine.config.autoResumeBottleReset = new == .auto
        }
    }
}

struct HistoryView: View {
    @EnvironmentObject var store: GameStore

    var body: some View {
        List {
            if store.plays.isEmpty {
                Text("No plays yet. Every call lands here with its confidence and the evidence behind it.")
                    .foregroundStyle(Theme.muted)
            }
            ForEach(store.plays.reversed()) { play in
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 6) {
                        Text(play.banner).font(.subheadline.weight(.semibold))
                        if play.revised {
                            Image(systemName: "cloud.fill")
                                .font(.caption2).foregroundStyle(Theme.glass)
                        }
                    }
                    Text("\(Int(play.confidence * 100))% · \(play.applied ? "applied" : "not applied")")
                        .font(.caption.monospaced()).foregroundStyle(Theme.muted)
                    ForEach(play.reasons, id: \.self) { reason in
                        Text(reason).font(.caption).foregroundStyle(Theme.muted)
                    }
                }
                .padding(.vertical, 4)
            }
        }
        .navigationTitle("History")
    }
}
