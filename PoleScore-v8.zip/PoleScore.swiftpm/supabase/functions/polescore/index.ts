// PoleScore cloud vision — Supabase Edge Function (Deno).
//
// Deploy with:
//   supabase functions deploy polescore
//   supabase secrets set GEMINI_API_KEY=...
//
// Why this exists at all: the app must never ship a model API key. An anon
// Supabase key is safe in client code because row-level security bounds what it
// can do; a model provider key is not, because there is no equivalent bound —
// anyone who extracts it can spend your quota on anything. So the app calls
// this function with its anon key, and the model key stays here as a secret.
//
// Provider is chosen by whichever secret is set, so swapping is configuration
// rather than a code change:
//
//   GEMINI_API_KEY     Google AI Studio. Has a genuinely free tier with a
//                      per-minute request cap, which is why the app calls this
//                      once per play instead of once per frame.
//   ANTHROPIC_API_KEY  Claude. Paid per token, no free tier — use it if you
//                      want the accuracy and are willing to pay for it.
//
// With neither set, this returns 503 and the app carries on scoring entirely on
// device. That is a supported configuration, not a broken one.

const GEMINI_KEY = Deno.env.get("GEMINI_API_KEY");
const ANTHROPIC_KEY = Deno.env.get("ANTHROPIC_API_KEY");

const GEMINI_MODEL = Deno.env.get("GEMINI_MODEL") ?? "gemini-2.5-flash";
const ANTHROPIC_MODEL = Deno.env.get("ANTHROPIC_MODEL") ?? "claude-opus-5";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });

// ---------------------------------------------------------------------------
// Prompts
// ---------------------------------------------------------------------------

const COURT_PROMPT = `You are looking at one frame from a phone propped at the side of a
glow-in-the-dark Beersbee / Strike Pole court, at night. The court is two vertical poles
standing in the ground, roughly 20-40 feet apart, each with a glass bottle balanced on top.
Everything glowing is part of the set; everything else is dark.

Return the position of each pole in NORMALIZED image coordinates, where x=0 is the left edge,
x=1 the right edge, y=0 the TOP edge and y=1 the BOTTOM edge.

For each pole give two points:
  - the TOP of the pole: the point the bottle is balanced on.
  - the BASE of the pole: the point where the pole meets the ground.

The base points matter more than anything else in this image. They define the ground line,
which is what separates a bottle someone caught from a bottle lying in the grass, and that is
worth a point every time it is wrong. If a pole's base is hidden behind grass or out of frame,
estimate where the pole would meet the ground and lower your confidence.

Set found=false if you cannot see two distinct poles - an empty field, one pole, a wall of
streetlights, an indoor scene. A wrong answer is much worse than no answer here, because the
app has a working on-device estimate that yours would replace.`;

const PLAY_PROMPT = `You are reviewing one play in a game of Beersbee (also called Strike Pole).

The rules that matter:
  - Players throw a flying disc at the opposing team's pole, trying to knock the bottle off.
  - "bottle_ground"  - the bottle was knocked off the pole and hit the ground. Worth the most.
  - "bottle_caught"  - the bottle was knocked off but a defender caught it before it landed.
  - "disc_hits_pole" - the disc struck the pole but the bottle stayed on top.
  - "disc_ground"    - the disc landed on the ground without knocking the bottle off.
  - "disc_caught"    - a defender caught the disc; the bottle stayed on.
  - "dead_throw"     - nothing conclusive: a miss, a play that left frame, an unclear outcome.

The single hardest distinction is bottle_caught vs bottle_ground, because it is the difference
between two points and three. A catch means the bottle stopped moving while still WELL ABOVE
the grass, held by someone. A ground means it came to rest AT the grass line. In the dark you
often cannot see the player at all, so judge it by the height at which the bottle stopped.

The frames below are in time order and cover the whole play. You are also given what the
on-device detector measured and what it concluded.

Only disagree with the on-device call if the frames clearly show something different. It sees
every frame at full rate and you are seeing three stills; on ambiguous plays it is usually
right and your job is to confirm. Report confidence honestly - below 0.8 the app keeps its own
answer, which is the correct outcome when you are unsure.`;

const FEATURE_NAMES = [
  "bottleKnocked", "bottleGroundFrames", "bottleCaughtFrames", "bottleFinalHeight",
  "bottlePeakSpeed", "discSeen", "discGroundFrames", "discCaughtFrames",
  "discFinalHeight", "discPeakSpeed", "discPoleFrames", "duration", "quality", "occlusion",
];

const CALLS = [
  "bottle_ground", "bottle_caught", "disc_hits_pole", "disc_ground", "disc_caught", "dead_throw",
];

// Index in CALLS matches PlayClass raw values in the app. Keep them in step.
const describeFeatures = (features: number[]): string =>
  FEATURE_NAMES.map((name, i) => `  ${name}: ${(features[i] ?? 0).toFixed(3)}`).join("\n");

// ---------------------------------------------------------------------------
// Gemini
// ---------------------------------------------------------------------------

const COURT_SCHEMA_GEMINI = {
  type: "OBJECT",
  properties: {
    found: { type: "BOOLEAN" },
    left_top: pointSchemaGemini(),
    right_top: pointSchemaGemini(),
    left_base: pointSchemaGemini(),
    right_base: pointSchemaGemini(),
    confidence: { type: "NUMBER" },
    note: { type: "STRING" },
  },
  required: ["found", "confidence"],
};

function pointSchemaGemini() {
  return {
    type: "OBJECT",
    properties: { x: { type: "NUMBER" }, y: { type: "NUMBER" } },
    required: ["x", "y"],
  };
}

const PLAY_SCHEMA_GEMINI = {
  type: "OBJECT",
  properties: {
    call: { type: "STRING", enum: CALLS },
    confidence: { type: "NUMBER" },
    reason: { type: "STRING" },
  },
  required: ["call", "confidence", "reason"],
};

async function askGemini(prompt: string, images: string[], schema: unknown) {
  const parts: unknown[] = [{ text: prompt }];
  for (const image of images) {
    parts.push({ inline_data: { mime_type: "image/jpeg", data: image } });
  }

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts }],
        generationConfig: {
          temperature: 0,
          responseMimeType: "application/json",
          responseSchema: schema,
        },
      }),
    },
  );

  if (!response.ok) {
    throw new Error(`gemini ${response.status}: ${(await response.text()).slice(0, 300)}`);
  }
  const body = await response.json();
  const text = body?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (typeof text !== "string") throw new Error("gemini returned no text part");
  return JSON.parse(text);
}

// ---------------------------------------------------------------------------
// Claude
// ---------------------------------------------------------------------------

const COURT_SCHEMA_JSON = {
  type: "object",
  properties: {
    found: { type: "boolean" },
    left_top: pointSchemaJSON(),
    right_top: pointSchemaJSON(),
    left_base: pointSchemaJSON(),
    right_base: pointSchemaJSON(),
    confidence: { type: "number" },
    note: { type: "string" },
  },
  required: ["found", "left_top", "right_top", "left_base", "right_base", "confidence", "note"],
  additionalProperties: false,
};

function pointSchemaJSON() {
  return {
    type: "object",
    properties: { x: { type: "number" }, y: { type: "number" } },
    required: ["x", "y"],
    additionalProperties: false,
  };
}

const PLAY_SCHEMA_JSON = {
  type: "object",
  properties: {
    call: { type: "string", enum: CALLS },
    confidence: { type: "number" },
    reason: { type: "string" },
  },
  required: ["call", "confidence", "reason"],
  additionalProperties: false,
};

async function askClaude(prompt: string, images: string[], schema: unknown) {
  const content: unknown[] = images.map((image) => ({
    type: "image",
    source: { type: "base64", media_type: "image/jpeg", data: image },
  }));
  content.push({ type: "text", text: prompt });

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_KEY!,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: ANTHROPIC_MODEL,
      max_tokens: 4096,
      // Low effort on purpose: this is a perception call on three small stills
      // with a fixed answer set, not a reasoning problem, and the app is
      // waiting on it inside an undo window.
      output_config: { effort: "low", format: { type: "json_schema", schema } },
      messages: [{ role: "user", content }],
    }),
  });

  if (!response.ok) {
    throw new Error(`anthropic ${response.status}: ${(await response.text()).slice(0, 300)}`);
  }
  const body = await response.json();
  if (body.stop_reason === "refusal") throw new Error("anthropic declined the request");
  const text = body?.content?.find((b: { type: string }) => b.type === "text")?.text;
  if (typeof text !== "string") throw new Error("anthropic returned no text block");
  return JSON.parse(text);
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------

async function ask(prompt: string, images: string[], geminiSchema: unknown, jsonSchema: unknown) {
  if (GEMINI_KEY) return await askGemini(prompt, images, geminiSchema);
  if (ANTHROPIC_KEY) return await askClaude(prompt, images, jsonSchema);
  return null;
}

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (request.method !== "POST") return json({ error: "POST only" }, 405);

  if (!GEMINI_KEY && !ANTHROPIC_KEY) {
    // The app treats this as "carry on without me" and backs off. Deliberately
    // not an error the user ever sees.
    return json({ error: "no model key configured" }, 503);
  }

  let payload: Record<string, unknown>;
  try {
    payload = await request.json();
  } catch {
    return json({ error: "bad json" }, 400);
  }

  try {
    if (payload.task === "court") {
      const image = payload.image;
      if (typeof image !== "string" || image.length < 100) {
        return json({ error: "missing image" }, 400);
      }
      const lit = typeof payload.lit === "number" ? payload.lit : 0;
      const prompt = `${COURT_PROMPT}\n\nThe on-device detector currently sees ${lit} distinct lit regions in this frame.`;
      const result = await ask(prompt, [image], COURT_SCHEMA_GEMINI, COURT_SCHEMA_JSON);
      if (!result) return json({ error: "no model key configured" }, 503);
      return json(result);
    }

    if (payload.task === "play") {
      const images = Array.isArray(payload.images) ? payload.images.filter((i) => typeof i === "string") : [];
      if (images.length === 0) return json({ error: "missing images" }, 400);

      const features = Array.isArray(payload.features) ? payload.features as number[] : [];
      const ruleIndex = typeof payload.rule_call === "number" ? payload.rule_call : 5;
      const ruleCall = CALLS[ruleIndex] ?? "dead_throw";
      const ruleConfidence = typeof payload.rule_confidence === "number" ? payload.rule_confidence : 0;

      const prompt = `${PLAY_PROMPT}

What the on-device detector measured (heights are normalized against the detected ground line,
so 0 means exactly at the grass and larger means higher up; speeds are frame widths per second):
${describeFeatures(features)}

The on-device call was "${ruleCall}" with confidence ${ruleConfidence.toFixed(2)}.`;

      // Cap the frames actually sent. The app sends three; this is a belt to
      // that brace, because tokens per request is what the free tier meters.
      const result = await ask(prompt, images.slice(0, 4), PLAY_SCHEMA_GEMINI, PLAY_SCHEMA_JSON);
      if (!result) return json({ error: "no model key configured" }, 503);
      return json(result);
    }

    return json({ error: "unknown task" }, 400);
  } catch (error) {
    // Upstream rate limits land here. 502 tells the app to back off rather than
    // hammer a quota that has already run out.
    console.error(error);
    return json({ error: String(error).slice(0, 300) }, 502);
  }
});
